(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg = function() {
	this.initialize(img.bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,775);


(lib.bite = function() {
	this.initialize(img.bite);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.kreisais = function() {
	this.initialize(img.kreisais);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.labais = function() {
	this.initialize(img.labais);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// flash0_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQAbIAAgeIgLAQIgKAAIgKgQIAAAAIAAAeIgPAAIAAg0IAOAAIAQAaIAAAAIAQgaIAPAAIAAA0g");
	this.shape.setTransform(435.4131,69.6779,0.55,0.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAJAbIgTgYIAAAYIgOAAIAAg0IAOAAIAAAZIASgZIAQAAIAAABIgUAZIAVAYIAAACg");
	this.shape_1.setTransform(431.8933,69.6779,0.55,0.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAANADAGQADAHAGAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_2.setTransform(426.9573,69.0867,0.55,0.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAAaAMAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_3.setTransform(423.41,69.0867,0.55,0.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAAaAMAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_4.setTransform(419.8627,69.0867,0.55,0.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgMAAQAAAaAMAAQANAAAAgaQAAgZgNAAQgMAAAAAZg");
	this.shape_5.setTransform(414.9129,69.0867,0.55,0.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgMAAQAAAaAMAAQANAAAAgaQAAgZgNAAQgMAAAAAZg");
	this.shape_6.setTransform(411.3656,69.0867,0.55,0.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAlIAAgNIARAAIAAgtIgBAAIgNAEIgBAAIAAgNIATgGIAKAAIAAA8IAOAAIAAANg");
	this.shape_7.setTransform(407.8733,69.0867,0.55,0.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AALAbIAAggIgTAgIgQAAIAAg0IAOAAIAAAfIATgfIAQAAIAAA0g");
	this.shape_8.setTransform(402.896,69.6779,0.55,0.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbAPQAFAAADgDQACgEABgJIABgZIArAAIAAA0IgPAAIAAgoIgOAAIgCAOQgBAPgGAGQgFAGgMAAg");
	this.shape_9.setTransform(399.1975,69.6916,0.55,0.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAbIAAggIgTAgIgQAAIAAg0IAOAAIAAAfIATgfIAQAAIAAA0g");
	this.shape_10.setTransform(395.7739,69.6779,0.55,0.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgkCIIAAjVIhRAAIAAg5IDrAAIAAA5IhSAAIAADVg");
	this.shape_11.setTransform(434.5469,57.166,0.55,0.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhgBmQgignAAg/QAAg8AjgoQAlgrA+AAQA/AAAiAjQAeAfAAAzQAAAYgEAYIi0AAQACAdASAQQASAQAdAAQApAAAugRIARA3QgwAXg+AAQhCAAgmgqgAglhFQgPASgBAaIByAAIABgIQAAg3g5AAQgaAAgQATg");
	this.shape_12.setTransform(419.1477,57.166,0.55,0.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiPBMQAZAAANgPQAPgUADgyIAHh/IDgAAIAAEOIhKAAIAAjVIhTAAIgFBMQgHBSgfAfQgaAbg9AAg");
	this.shape_13.setTransform(400.8749,57.276,0.55,0.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAaIAAgRIgGAAIgOARIgPAAIAAgBIAPgRQgMgDAAgNQAAgSAVAAIAZAAIAAA0gAgGgIQAAAGAGABIALAAIAAgOIgLAAQgGAAAAAHg");
	this.shape_14.setTransform(427.6998,45.3966,0.55,0.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AALAaIAAggIAAAAIgTAgIgQAAIAAg0IAOAAIAAAhIABAAIASghIARAAIAAA0g");
	this.shape_15.setTransform(424.3862,45.3966,0.55,0.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgGAaIAAgpIgQAAIAAgLIAtAAIAAALIgQAAIAAApg");
	this.shape_16.setTransform(421.2239,45.3966,0.55,0.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AALAaIAAgUIgUAAIAAAUIgPAAIAAg0IAPAAIAAAVIAUAAIAAgVIAOAAIAAA0g");
	this.shape_17.setTransform(418.0615,45.3966,0.55,0.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaALQAAgQAaAAIAHAAIAAgDQAAgHgIAAQgKAAgIAEIgDgMQAKgEALAAQAWAAAAAVIAAAVQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEAAIAAAKIgIAAQgIABgDgHQgHAHgJAAQgSAAAAgRgAgMAKQAAAGAIABQAGAAAFgFIAAgJIgGAAQgNAAAAAHg");
	this.shape_18.setTransform(414.6929,45.3966,0.55,0.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgZAmIAAhKIAKAAIACAFQAKgGAGAAQALAAAHAIQAFAIABAMQgBALgFAIQgHAIgLAAQgGAAgHgFIAAAZgAgKgWIAAAYQAEAEAGAAQALAAAAgPQAAgQgLAAQgFAAgFADg");
	this.shape_19.setTransform(411.3243,45.9466,0.55,0.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaALQAAgQAaAAIAHAAIAAgDQAAgHgIAAQgJAAgJAEIgEgMQALgEALAAQAWAAAAAVIAAAVQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEAAIAAAKIgIAAQgIABgDgHQgHAHgJAAQgSAAAAgRgAgMAKQAAAGAHABQAGAAAGgFIAAgJIgGAAQgNAAAAAHg");
	this.shape_20.setTransform(407.8733,45.3966,0.55,0.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgYAlIAAhJIAxAAIAAAMIgiAAIAAA9g");
	this.shape_21.setTransform(405.3021,44.7916,0.55,0.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AmaHLQAYgUAUgZIUIAAIAAqHIzVAAIAAgtIUDAAIAALhgAs3G+QhQgNhAgXIAribQA3AYBEAMQA6ALAxgBQBYABAugmQAtglAAhEQAAhCgrgfQgtgjhhAAQhEAAhxAIIgWgXIAynWIHtAAIAACaIlSAAIgSCyQAlgDAVAAQCcAABUBCQBeBHAACXQAACOhkBPQhjBOiwABQgzAAhJgNg");
	this.shape_22.setTransform(401.2751,52.7669,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(348.1,27.6,106.39999999999998,50.4);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#001E50").s().p("EghIATiMAAAgnDMBCRAAAMAAAAnDg");
	this.shape.setTransform(212.1,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,424.2,250);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.labais();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.kreisais();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bite();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#001E50").s().p("AgaAfQgJgMAAgTQAAgSAJgNQAKgNARAAQARAAAKALQAIAKAAAQIgBAKIg4AAQAAAMAHAJQAIAIAKAAQAMAAALgHIAFALQgMAJgSAAQgSAAgKgOgAgOgYQgFAGgBAMIApAAIAAgFQAAgJgFgFQgFgHgKAAQgJAAgGAIg");
	this.shape.setTransform(119.175,23.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#001E50").s().p("AgaAfQgJgMAAgTQAAgSAJgNQAKgNARAAQARAAAKALQAIAKAAAQIgBAKIg4AAQAAAMAHAJQAIAIAKAAQAMAAALgHIAFALQgMAJgSAAQgSAAgKgOgAgOgYQgFAGgBAMIApAAIABgFQAAgJgGgFQgFgHgKAAQgJAAgGAIg");
	this.shape_1.setTransform(110.175,23.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#001E50").s().p("AATAqIAAglIglAAIAAAlIgOAAIAAhTIAOAAIAAAjIAlAAIAAgjIAOAAIAABTg");
	this.shape_2.setTransform(100.875,23.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#001E50").s().p("AgbAzQgKgMAAgZQAAgdADgNQAIgVAUgIQALgDAdgDIAAANQgaACgKAFQgMAEgEAKQgFAJAAARIAAABQALgOAPAAQARAAAJALQAJAKAAASQABASgLALQgKAMgSAAQgRAAgKgNgAgRADQgGAIAAAMQAAAMAGAIQAIAIAJAAQALAAAGgIQAHgIAAgMQAAgMgHgIQgGgGgLgBQgKABgHAGg");
	this.shape_3.setTransform(91.3,21.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#001E50").s().p("AgdAfQgIgLgBgUQABgTAIgMQALgNASAAQAUAAAKANQAJAMAAATQAAAUgJALQgLAOgTAAQgSAAgLgOgAgXAAQAAAhAXgBQAYABgBghQABgggYAAQgXAAAAAgg");
	this.shape_4.setTransform(81.55,23.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#001E50").s().p("AgjA9IAAh2IAKAAIACAHIAAAAQAOgKAMAAQARAAAJANQAHAMAAAUQAAATgHALQgJAOgRAAQgNAAgLgIIAAAAIAAAogAgVgoIAAAxQAIAHANAAQAVABAAggQAAghgVAAQgMAAgJAIg");
	this.shape_5.setTransform(72.2,24.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#001E50").s().p("AAcA1IgBgVIg1AAIgBAVIgLAAIgCgiIAHAAQAKgLABgaIACgiIA0AAIAABHIAJAAIgDAigAgJgSQgCAdgGAIIAjAAIAAg7IgZAAg");
	this.shape_6.setTransform(62.225,24.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#001E50").s().p("AgdAfQgIgLAAgUQAAgsAlAAQATAAAKANQAJAMAAATQAAAUgJALQgKAOgTAAQgTAAgKgOgAgXAAQAAAhAXgBQAYABAAghQAAgggYAAQgXAAAAAgg");
	this.shape_7.setTransform(52.925,23.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#001E50").s().p("AAbA8IAAhqIg1AAIAABqIgPAAIAAh3IBTAAIAAB3g");
	this.shape_8.setTransform(42.275,21.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ApDDcQhbAAhAhBQhBhAAAhbQAAhaBBhAQBAhBBbAAISHAAQBbAABABBQBBBAAABaQAABbhBBAQhABBhbAAg");
	this.shape_9.setTransform(80,22);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4CC7F4").s().p("ApDDcQhbAAhAhBQhBhAAAhbQAAhaBBhAQBAhBBbAAISHAAQBbAABABBQBBBAAABaQAABbhBBAQhABBhbAAg");
	this.shape_10.setTransform(80,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,44);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg();
	this.instance.setTransform(29,0,0.9066,0.9066);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(29,0,816,702.6);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0BTQgWgNgLgVQgLgWAAgbQAAgaALgWQALgWAWgNQAVgNAfAAQAgAAAVANQAWANALAWQALAWAAAaQAAAbgLAWQgLAVgWANQgVANggABQgfgBgVgNgAgfgoQgMAOAAAaQAAAcAMANQAMAOATAAQAUAAAMgOQAMgNAAgcQAAgagMgOQgMgOgUAAQgTAAgMAOg");
	this.shape.setTransform(241.175,30.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgqCBQgSgFgNgHIAOgmQAMAGAOAEQAOAEARAAQAWAAAKgKQALgJAAgXIAAgNIgBAAQgIAGgNAGQgMAGgSAAQgaAAgSgNQgSgMgJgWQgJgUAAgbQAAgbAJgVQAJgWASgNQASgNAaAAQAMAAALAEQAKADAIAFIAOAKIABAAIAHgQIAoAAIAACqQAAAugZAXQgYAYgtAAQgWgBgSgFgAgchNQgLAOAAAZQAAAZALANQAKAOAWAAQAKAAAJgDIASgHIAAhVQgIgEgKgDQgJgEgKAAQgWABgKAOg");
	this.shape_1.setTransform(218.575,34.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BeIAAi2IApAAIAHAWIABAAQAEgGAFgGQAGgHAJgEQAJgEAMAAIAKAAIAJACIgEArIgKgBIgJgBQgPABgKAFQgJAGgFAGIAAB+g");
	this.shape_2.setTransform(201.65,30.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BZQgOgHgHgNQgHgNAAgQQgBgfAWgNQAVgQAwABIAYAAIAAgJQAAgLgGgGQgFgGgHgCQgGgBgGAAQgQAAgPADQgQAEgOAHIgMgoQAPgHATgEQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABACAEAAIAOAAIAAAiIgNACIgOABQgPAAgIgGQgJgFgEgLIgBAAQgKAJgQAGQgPAIgRAAQgVAAgNgIgAgfASQgLAHAAAKQAAALAGAGQAHAFALAAQALAAAKgEQAMgDAIgGIAAgfIgTAAQgYAAgLAFg");
	this.shape_3.setTransform(183.3994,30.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpB2QgcgRgPgeQgOgeAAgpQAAgoAOgeQAPgeAcgRQAbgQAogBQASAAATAEQASAFATAIIgPAqQgPgHgOgEQgOgDgQAAQgXABgPALQgQALgHAUQgIAUAAAaQAAAbAIAUQAHAUAQALQAPALAXABQAQAAAOgDQAOgEAPgHIAPAqQgTAIgSAFQgTAEgSAAQgogBgbgQg");
	this.shape_4.setTransform(161.65,26.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBbIAAgbIBXhzIAAgBIhRAAIAAgmICQAAIAAAaIhXB0IAAABIBXAAIAAAmg");
	this.shape_5.setTransform(132.05,30.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKBbIAAgbIBXhzIAAgBIhSAAIAAgmICRAAIAAAaIhYB0IAAABIBYAAIAAAmg");
	this.shape_6.setTransform(114.1,30.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhEBKQgRgTAAgiIAAhyIAzAAIAABtQAAASAHAJQAIAJAQAAQAMAAAKgFQAKgFAGgFIAAiCIAzAAIAAC2IgpAAIgHgSIgBAAQgFAFgIAFQgIAGgLADQgJAEgPAAQghAAgQgUg");
	this.shape_7.setTransform(94.225,31.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhkCBIAAkBIBfAAQAuAAAYAQQAYARABAlQgBAVgJANQgKANgOAGIAAABQAVAGAMAPQALAPABAYQAAAkgXATQgWASgyAAgAgvBVIAwAAQAYAAAKgIQALgIAAgRQAAgSgLgIQgLgIgYAAIgvAAgAgvgXIAoAAQAVAAALgHQAKgGAAgRQAAgSgKgGQgKgHgXAAIgnAAg");
	this.shape_8.setTransform(71.675,26.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgXAXQgIgIAAgPQAAgNAIgKQAJgIAOgBQAPABAJAIQAIAKAAANQAAAPgIAIQgJAJgPAAQgOAAgJgJg");
	this.shape_9.setTransform(44.625,37.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhqCBIAAkBIBRAAQAvAAAeAPQAdAPANAcQANAdAAApQAAAqgNAdQgNAcgdAPQgeAPgvAAgAg1BVIAXAAQAgAAASgJQASgJAHgTQAHgTgBgdQABgcgHgTQgHgTgSgJQgSgJggAAIgXAAg");
	this.shape_10.setTransform(26.925,26.975);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZCBIAAkBIAzAAIAAEBg");
	this.shape_11.setTransform(7.65,26.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,254.5,50.3);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXB7QgIgJAAgPQAAgOAIgJQAJgJAOAAQAPAAAJAJQAIAJAAAOQAAAPgIAJQgJAJgPAAQgOAAgJgJgAgQAjIgKhtIAAg5IA2AAIAAA5IgLBtg");
	this.shape.setTransform(207.175,27.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BZQgOgHgHgNQgHgNAAgQQgBgfAWgNQAVgQAwABIAYAAIAAgJQAAgLgGgGQgFgGgHgCQgGgBgGAAQgQAAgPADQgQAEgOAHIgMgoQAPgHATgEQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABACAEAAIAOAAIAAAiIgNACIgOABQgPAAgIgGQgJgFgEgLIgBAAQgKAJgQAGQgPAIgRAAQgVAAgNgIgAgfASQgLAHAAAKQAAALAGAGQAHAFALAAQALAAAKgEQAMgDAIgGIAAgfIgTAAQgYAAgLAFg");
	this.shape_1.setTransform(191.6994,30.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAfBbIhChQIgBAAIAABQIgyAAIAAi1IAyAAIAABXIABAAIBAhXIA3AAIAAACIhHBZIBKBYIAAACg");
	this.shape_2.setTransform(172.125,30.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhgBdIAAgqQAKABAIgFQAIgEAFgMQAFgNACgYIAEhWICXAAIAAC2IgyAAIAAiPIg3AAIgEAzQgDAmgKAVQgKAVgSAHQgRAIgXAAIgDAAg");
	this.shape_3.setTransform(148.925,30.8765);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguB9QgVgNgKgWQgKgWAAgbQAAgbAKgUQAKgWAVgNQAUgNAdAAQAeAAASAKQAUALAIARQAJASAAAVIgBATIgBAOIh6AAQACATAMAMQAMAKAUABQAPgBAPgDQAPgDANgFIAMAlQgOAHgTAEQgTAFgXgBQgeAAgVgNgAgRgLQgJAGgFAIQgEAKgBAMIBNAAIAAgEIAAgDQABgPgJgKQgIgKgVgBQgMABgJAGgAAZhZQgIgHAAgNQAAgNAIgHQAIgIAOAAQAOAAAHAIQAJAHAAANQAAANgJAHQgHAIgOAAQgOAAgIgIgAg5hZQgJgHAAgNQAAgNAJgHQAIgIANAAQAOAAAIAIQAIAHAAANQAAANgIAHQgIAIgOAAQgNAAgIgIg");
	this.shape_4.setTransform(128.25,26.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeBbIAAg5QgKAEgLACQgLACgQAAQgTAAgNgHQgOgIgHgMQgHgNAAgNIAAhPIAyAAIAABKQAAAJAGAFQAGADANABQAMAAAHgCQAJAAAFgDIAAhXIAxAAIAAC1g");
	this.shape_5.setTransform(107.65,30.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAlBbIAAiPIhJAAIAACPIgyAAIAAi1ICsAAIAAC1g");
	this.shape_6.setTransform(87.15,30.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAfBbIhChQIgBAAIAABQIgyAAIAAi1IAyAAIAABXIABAAIBAhXIA3AAIAAACIhHBZIBKBYIAAACg");
	this.shape_7.setTransform(58.175,30.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/BZQgOgHgHgNQgHgNAAgQQgBgfAWgNQAVgQAwABIAYAAIAAgJQAAgLgGgGQgFgGgHgCQgGgBgGAAQgQAAgPADQgQAEgOAHIgMgoQAPgHATgEQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABACAEAAIAOAAIAAAiIgNACIgOABQgPAAgIgGQgJgFgEgLIgBAAQgKAJgQAGQgPAIgRAAQgVAAgNgIgAgfASQgLAHAAAKQAAALAGAGQAHAFALAAQALAAAKgEQAMgDAIgGIAAgfIgTAAQgYAAgLAFg");
	this.shape_8.setTransform(36.8994,30.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAsCBIhfhzIgBAAIAABzIg0AAIAAkBIA0AAIAAB9IABAAIBdh9IA7AAIAAAEIhjB/IBoB6IAAAEg");
	this.shape_9.setTransform(15.55,26.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,223.6,50.3);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#001E50").s().p("EghIATiMAAAgnDMBCRAAAMAAAAnDg");
	this.shape.setTransform(212.1,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,424.2,250);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnbHcIAAu3IO3AAIAAO3g");
	mask.setTransform(47.55,47.575);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjfDgQhdhcAAiEQAAiCBdhdQBdhdCCAAQCEAABdBdQBcBdAACCQAACEhcBcQhdBdiEAAQiCAAhdhdgAkeAAQAAB2BUBVQBVBVB1AAQB2AABUhVQBVhVAAh2QAAg0gSgwIioFRQgEAIgGAAQgHAAgDgIIhOitIgDgDIgDADIhMCtQgEAIgHAAQgHAAgDgIIiolRQgSAwAAA0gAAZAIQAGAAACAGIA3B+IAEADQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBICTkmQgqg/g+giIhpDqQgCAFgGAAIgxAAQgGAAgCgFIhpjqQg/AigpA/ICSEmQADADACAAIADgDIA3h+QACgGAGAAgAhdkOIBaDKQABABAAABQABAAAAABQABAAAAABQAAAAAAAAQAAAAABAAQAAgBABAAQAAgBABAAQAAgBAAgBIBbjKQgsgRgyAAQgwAAgtARg");
	this.shape.setTransform(47.55,47.575);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(15.9,15.9,63.4,63.4), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AE8CCQgugmgMg5IAsAAQALAoAhAZQAiAaArAAQA0AAAkglQAlglAAg0QAAgzglglQgkglg0AAQgrAAgiAaQghAZgLAoIgsAAQAMg5AugmQAvgmA8AAQBFAAAxAxQAxAyAABEQAABGgxAxQgxAxhFAAQg8AAgvgmgADDChIhZh+IAzAAIBWB2IAAAIgAgDChIAAh+IArAAIAAB+gAkJChIAAh+IAsAAIAABWICjAAIAAAogAoaChIAAgjIA8hbIAyAAIg4BVIAAABICjAAIAAAogAGQAaQgJgIgCgNImIAAIAAgJIGIAAQACgNAJgIQAKgIANAAQAOAAAKAKQAKAKAAANQAAAOgKAKQgKAKgOAAQgNAAgKgIgAh/AbIAAgHIAEAAQAEAAABgDIABgDIgLgbIAAAAIAIAAIAHASIAGgSIAJAAIAAAAIgNAfQgDAJgIAAgAlQAYIADgGQACACAHAAQAGAAAAgGIAAgCQgEADgEAAQgMAAAAgPQAAgOAMAAQAEAAAFADIABgCIAGAAIAAAaQAAAOgOAAQgGAAgGgDgAlKAAQAAAIAHAAIAFgBIAAgNQgCgBgDAAQgHAAAAAHgAgtALQgEgEAAgHQAAgOAPAAQAPAAAAAOQAAAHgEAEQgEAEgHAAQgHAAgEgEgAgpAAQAAAJAHAAQAHAAAAgJQAAgHgHAAQgHAAAAAHgAhIAHIAAgOIgFAAIAAgEIAFgCIAAgHIAIAAIAAAHIAIAAIAAAGIgIAAIAAAMQAAABAAABQABAAAAABQABAAAAABQABAAABAAIAEgBIAAAGIgHABQgJAAAAgIgAiOAMQgEADgFAAQgKAAAAgJQAAgIAPAAIADAAIAAgBQAAgEgEAAQgGAAgEACIgCgGQAGgDAGAAQAMAAAAAMIAAAKIABABIACAAIAAAGIgEAAQgEAAgCgDgAiZAGQAAABAAAAQABABAAAAQABABAAAAQABAAABAAQADAAADgCIAAgFIgDAAQgHAAAAAEgAktAAQAAgFADgFQAEgEAHAAQAHAAADAEQAEADAAAFIgBAEIgTAAQAAAHAHAAQAGAAADgCIACAGQgFACgGAAQgPAAAAgPgAklgCIAMAAIAAAAQAAgGgGAAQgGAAAAAGgAliAMQgFADgFAAQgJAAAAgJQAAgIAOAAIAEAAIAAgBQAAgEgFAAQgGAAgEACIgCgGQAGgDAGAAQAMAAAAAMIAAAKIABABIADAAIAAAGIgFAAQgDAAgCgDgAluAGQAAADAEAAQAEAAADgCIAAgFIgDAAQgIAAAAAEgAnIANIACgGQAFACAEAAQAFAAAAgDQAAgBgEgCIgEAAQgIgCAAgGQAAgJAMAAQAFAAAGACIgCAGQgEgCgFAAQgBAAgBAAQAAABgBAAQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQABAAABABIADAAQAIACAAAGQAAAJgMAAQgGAAgFgCgAogALQgEgEAAgHQAAgOAPAAQAPAAAAAOQAAAHgEAEQgEAEgHAAQgHAAgEgEgAocAAQAAAJAHAAQAHAAAAgJQAAgHgHAAQgHAAAAAHgAn2APQgIAAAAgIIAAghIAIAAIAAAiIABABIADAAIAAAGgAi3AOIgHgTIgGATIgJAAIgJgbIAAAAIAIAAIAGATIAGgTIAIAAIAHATIAFgTIAIAAIAAAAIgJAbgAj2AOIAAgQQAAgFgFAAIgGACIAAATIgIAAIAAgbIAHAAIABADQAEgEAFAAQAKAAAAALIAAARgAmMAOIgHgTIgGATIgJAAIgIgbIAAAAIAIAAIAFATIAGgTIAJAAIAGATIAFgTIAIAAIAAAAIgIAbgAnYAOIgKgNIAAANIgIAAIAAgoIAIAAIAAAaIAKgNIAJAAIAAAAIgLANIALAOIAAAAgAo/AOIgOgmIAAgBIAIAAIALAfIAKgfIAJAAIAAABIgOAmgACngiQALgNAAgWQAAg0g/AAIhLAAIAABXIgrAAIAAh+IB4AAQAzAAAbAXQAcAYAAAsQAAAUgFAPgAkJgiIAAh+IDNAAIAAAnIihAAIAABXgAmwgiIA5hWIAAgBIibAAIAAgnIDRAAIAAAjIg8Bbg");
	this.shape_1.setTransform(261.6247,-21.5273,1.1847,1.1847);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(191.7,-41.4,139.90000000000003,39.8), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgSBFIAAhrIgpAAIAAgeIB3AAIAAAeIgpAAIAABrg");
	this.shape_2.setTransform(314.75,-48.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhEBjIAAjBIAdAAIAFAMIABAAIALgHQAFgEAJgCQAIgDAJAAQAUAAANAKQAOAKAGAQQAHARAAAUQAAAUgHAQQgGAQgOAKQgNAKgUAAQgNAAgJgFIgQgJIAAAAIAABCgAgRhAQgHACgFAEIAABBQAFAEAHACQAIACAHAAQAQAAAIgLQAIgKAAgTQAAgTgIgLQgIgLgQAAQgHAAgIACg");
	this.shape_3.setTransform(300.05,-46.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgnA/QgQgKgIgQQgJgQAAgVQAAgTAJgRQAIgQAQgKQAQgJAXgBQAYABAQAJQAQAKAIAQQAJARAAATQAAAVgJAQQgIAQgQAKQgQAKgYAAQgXAAgQgKgAgXgeQgJAKAAAUQAAAVAJAKQAJALAOAAQAPAAAJgLQAJgKAAgVQAAgUgJgKQgJgKgPAAQgOAAgJAKg");
	this.shape_4.setTransform(282.875,-48.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAcBFIAAhrIg3AAIAABrIglAAIAAiJICBAAIAACJg");
	this.shape_5.setTransform(266.175,-48.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYBAQgQgJgIgQQgJgRAAgWQAAgVAJgQQAIgRAQgJQARgIAWgBQANABALACQAMADAHACIgIAeIgOgEQgHgCgKAAQgKgBgJAFQgHAEgFAJQgGAKAAANQAAAPAGAJQAEAKAIADQAJAFAKAAQAKAAAHgCIAOgFIAIAeIgTAFQgLADgNAAQgWAAgRgJg");
	this.shape_6.setTransform(250.9,-48.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcBFIAAg2Ig3AAIAAA2IglAAIAAiJIAlAAIAAA2IA3AAIAAg2IAlAAIAACJg");
	this.shape_7.setTransform(235.575,-48.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgvBEQgLgGgFgKQgFgKgBgMQABgXAPgKQAQgMAlAAIARAAIAAgFQAAgJgEgEQgEgEgGgCQgEgCgEABQgMAAgLADQgNACgKAFIgJgeQALgFAOgDQAPgDAQgBQAeABAOAOQAPAOAAAbIAAA3IAAAEIAFABIAKAAIAAAaIgJACIgMAAQgKABgHgFQgGgEgEgIIgBAAQgGAGgNAGQgLAFgNAAQgPAAgKgFgAgYAOQgHAFgBAHQABAJAFAEQAEAEAJAAQAIAAAHgCQAJgDAGgEIAAgZIgPAAQgRABgJAEg");
	this.shape_8.setTransform(219.55,-48.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhEBjIAAjBIAdAAIAFAMIAAAAIAMgHQAFgEAJgCQAIgDAJAAQAUAAAOAKQANAKAGAQQAHARAAAUQAAAUgHAQQgGAQgNAKQgOAKgUAAQgNAAgJgFIgQgJIAAAAIAABCgAgRhAQgHACgFAEIAABBQAFAEAHACQAHACAJAAQAQAAAHgLQAIgKAAgTQAAgTgIgLQgHgLgQAAQgJAAgHACg");
	this.shape_9.setTransform(203.55,-46.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgSBFIAAhrIgpAAIAAgeIB3AAIAAAeIgqAAIAABrg");
	this.shape_10.setTransform(188.15,-48.875);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAcBlIAAhWIgBAAIgyBWIgqAAIAAiIIAmAAIAABVIAAAAIAzhVIAqAAIAACIgAgchBQgMgGgHgLIAMgSQAHAFAJADQAKACAKAAQAMAAAJgCQAKgCAHgGIAMASQgHALgNAGQgMAFgSAAQgRAAgMgFg");
	this.shape_11.setTransform(373.45,-82.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAdBFIAAhWIgBAAIgzBWIgqAAIAAiJIAlAAIAABVIABAAIAyhVIArAAIAACJg");
	this.shape_12.setTransform(356.5,-78.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAXBFIgxg9IgBAAIAAA9IgmAAIAAiJIAmAAIAABCIABAAIAwhCIApAAIAAACIg2BDIA5BCIAAACg");
	this.shape_13.setTransform(341.125,-78.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgYBAQgQgJgIgQQgJgQAAgXQAAgVAJgQQAIgRAQgJQAQgIAXgBQANAAALADQALADAIADIgIAdIgOgEQgHgCgKAAQgKAAgJAEQgIAEgEAJQgGAJAAAOQAAAPAGAJQAEAKAIADQAIAEALABQAKgBAHgCIAOgDIAIAdIgTAGQgLACgNAAQgXAAgQgJg");
	this.shape_14.setTransform(325.85,-78.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgjA/QgPgJgIgRQgHgRAAgUQAAgTAHgQQAIgRAPgKQAPgKAWAAQAXAAAOAJQAOAHAHANQAHAOAAAQIgBANIgCALIhbAAQACAPAIAIQAJAIAPABQAMgBALgCIAVgGIAJAcQgKAEgPAEQgOADgRAAQgWAAgRgKgAgNgnQgGAEgDAIQgEAHgBAJIA6AAIABgDIAAgCQgBgMgGgHQgHgJgPAAQgJAAgHAFg");
	this.shape_15.setTransform(311.2,-78.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAWBFIAAgsQgHAEgIABQgIACgMAAQgPAAgJgGQgKgGgGgJQgGgJAAgLIAAg7IAmAAIAAA5QAAAGAFADQAEADAKAAIAOgBQAHAAADgDIAAhBIAmAAIAACJg");
	this.shape_16.setTransform(295.6,-78.775);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhEBjIAAjBIAcAAIAGAMIABAAIALgHQAFgEAJgCQAIgDAKAAQATAAANAKQAOAKAGAQQAHARAAAUQAAAUgHAQQgGAQgOAKQgNAKgTAAQgOAAgJgFIgQgJIgBAAIAABCgAgQhAQgIACgGAEIAABBQAGAEAIACQAHACAHAAQAQAAAIgLQAIgKAAgTQAAgTgIgLQgIgLgQAAQgHAAgHACg");
	this.shape_17.setTransform(280.35,-76.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgiA/QgQgJgIgRQgIgRAAgUQAAgTAIgQQAIgRAQgKQAPgKAVAAQAXAAAOAJQAOAHAHANQAGAOAAAQIAAANIgBALIhbAAQAAAPAKAIQAIAIAPABQAMgBALgCIAVgGIAJAcQgLAEgOAEQgOADgRAAQgXAAgPgKgAgNgnQgHAEgDAIQgDAHAAAJIA5AAIAAgDIAAgCQAAgMgGgHQgGgJgRAAQgIAAgHAFg");
	this.shape_18.setTransform(263.9,-78.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAqBFIAAhOIAAAAIgbAtIgdAAIgbgtIAAAAIAABOIgmAAIAAiJIAlAAIAqBHIAAAAIArhHIAlAAIAACJg");
	this.shape_19.setTransform(246.275,-78.775);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAqBFIAAhOIAAAAIgbAtIgdAAIgbgtIAAAAIAABOIgmAAIAAiJIAlAAIAqBHIAAAAIArhHIAlAAIAACJg");
	this.shape_20.setTransform(226.625,-78.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgnA/QgQgJgIgRQgJgRAAgUQAAgTAJgQQAIgRAQgKQAQgJAXgBQAYABAQAJQAQAKAIARQAJAQAAATQAAAUgJARQgIARgQAJQgQAKgYAAQgXAAgQgKgAgXgeQgJALAAATQAAAVAJAKQAJALAOAAQAPAAAJgLQAJgKAAgVQAAgTgJgLQgJgKgPAAQgOAAgJAKg");
	this.shape_21.setTransform(208.375,-78.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAhBhIhHhXIgBAAIAABXIgnAAIAAjBIAnAAIAABeIABAAIBFheIAsAAIAAADIhJBfIBNBcIAAADg");
	this.shape_22.setTransform(191.8,-81.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(179.1,-102.9,205.6,69.7), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AnSHTIAAulIOlAAIAAOlg");
	mask_1.setTransform(46.7,46.7);

	// Layer_3
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AlJFKQiJiIAAjCQAAjBCJiIQCIiJDBAAQDCAACICJQCJCIAADBQAADCiJCIQiICJjCAAQjBAAiIiJgAmmAAQAACvB8B8QB8B9CuAAQCuAAB9h9QB7h8AAivQAAhMgahHIj3HxQgGAMgKAAQgIAAgGgMIhyj/QgCgFgDgBQgBABgDAFIhyD/QgFAMgKAAQgJAAgGgMIj3nxQgbBIAABLgAAlANQAJgBADAJIBRC4QACAGADAAQADAAACgGIDYmwQg9hchcgzIiaFYQgDAIgJAAIhKAAQgIAAgDgIIialYQhdAzg7BcIDXGwQADAGACAAQADAAACgGIBRi4QADgJAIABgAiKmPICGErQADAFABAAQADAAACgFICGkrQhEgYhHAAQhHAAhDAYg");
	this.shape_23.setTransform(46.7,46.7);

	var maskedShapeInstanceList = [this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,93.4,93.4), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgLAMQgEgEgBgIQABgGAEgFQAFgEAGgBQAHABAFAEQAFAFAAAGQAAAIgFAEQgFAFgHAAQgGAAgFgFg");
	this.shape_24.setTransform(470.875,30.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AA2B+IAAiXIgBAAIhpCXIgSAAIAAi2IASAAIAACYIAAAAIBpiYIATAAIAAC2gAgbhiQgMgIgFgMIAKgHQAFAIAHAFQAIAGAQAAQAQAAAJgGQAHgFAFgIIAKAHQgFAMgMAIQgKAIgUAAQgSAAgLgIg");
	this.shape_25.setTransform(456.15,19.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABFBcIAAi2IASAAIAAC2gAhWBcIAAi2IASAAIAABLIAxAAQAdAAAQAOQAQANABAaQgBAagQANQgQAOgdABgAhEBLIAvAAQANABAKgEQAKgEAHgHQAGgJAAgOQAAgOgGgIQgHgJgKgDQgKgDgNAAIgvAAg");
	this.shape_26.setTransform(433.875,22.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhABcIAAi2IA6AAQAggBAPAMQAPAMAAAaQAAAMgHALQgIALgLAFIAAAAQAQADAKALQAJALAAARQAAAQgFALQgHAMgNAGQgOAHgYAAgAguBLIAwAAQAVABALgJQAMgIAAgSQAAgTgMgIQgLgIgVABIgwAAgAgugJIAoAAQASABANgIQAMgHAAgSQAAgTgMgHQgNgHgSAAIgoAAg");
	this.shape_27.setTransform(413.25,22.799);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AA2BcIAAiYIgBAAIhpCYIgSAAIAAi2IASAAIAACYIAAAAIBpiYIATAAIAAC2g");
	this.shape_28.setTransform(393.15,22.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgsB/QgTgLgMgXQgLgXAAgkQgBgiAFgcQAEgcANgVQANgWAbgOQAPgGARgFIAlgHIAfgGIAAASQgMADgPABQgPACgRAEQgRADgRAJQgTAKgKAOQgLAOgEATQgFATAAAZIAAAAQAKgRASgKQATgKAXgBQAZABATAKQATALALASQAKATAAAbQAAAZgKATQgLAUgUALQgTALgbAAIgBAAQgYAAgTgLgAgjgIQgPAIgIAQQgJAPAAAVQAAAUAJAQQAIAPAPAJQAPAJAUAAQAWAAAPgJQAPgJAIgPQAIgQAAgUQAAgVgIgPQgIgQgPgIQgPgIgWAAQgUAAgPAIg");
	this.shape_29.setTransform(371.8725,18.7261);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgRBUQgTgMgIgWQgJgUAAgZIgsAAIAABXIgSAAIAAi2IASAAIAABRIAtAAQABgYAIgTQAJgUASgMQARgMAeAAQAgAAATAOQATANAIAXQAHAVAAAZQAAAZgHAWQgIAXgTANQgTAOggAAQgfAAgRgNgAgJhDQgOALgGATQgGASABATQgBAUAGASQAGASAOAMQAOAMAaAAQAbAAAOgMQAOgMAGgSQAFgSAAgUQAAgTgFgSQgGgTgOgLQgOgMgbAAQgaAAgOAMg");
	this.shape_30.setTransform(346.6,22.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AhPBdIAAgRQAJAAAFgCQAHgCADgIQAEgIADgRQACgRABgeIAEhUIB5AAIAAC2IgSAAIAAimIhWAAIgDBCQgBAhgDAUQgEAVgFAKQgHALgJAEQgIAEgMAAIgDAAg");
	this.shape_31.setTransform(320.65,22.9278);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgyBTQgTgNgHgXQgIgWAAgZQAAgZAIgVQAHgXATgNQATgOAfAAQAgAAATAOQATANAHAXQAIAVAAAZQAAAZgIAWQgHAXgTANQgTAOggAAQgfAAgTgOgAgohDQgOALgGATQgFASAAATQAAAUAFASQAGASAOAMQAPAMAZAAQAaAAAPgMQAOgMAGgSQAFgSAAgUQAAgTgFgSQgGgTgOgLQgPgMgaAAQgZAAgPAMg");
	this.shape_32.setTransform(301.275,22.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("ABCByIgCgtIiAAAIgCAtIgPAAIgDg+IAMAAQAJgIAGgKQAHgLAEgQQAEgPACgZIAFhQIBnAAIAAClIARAAIgDA+gAgXggQgCAagEAPQgEAQgFAKQgGAKgHAHIBlAAIAAiVIhEAAg");
	this.shape_33.setTransform(280.225,25.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AhBCDIgMgDIAAgQIALACIANABQANAAAJgKQAJgKAGgOIALgfIhKizIAAgCIAUAAIA+CdIABAAIA5idIATAAIAAACIhODTQgIAZgOAMQgNAMgTABIgNgBg");
	this.shape_34.setTransform(262,26.85);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AhNCEIAAkBIAPAAIACARIABAAQAKgKAQgGQAPgHAVAAQAcAAAQANQARANAGAWQAIAWAAAbQAAAbgIAUQgGAXgRAMQgQANgcABQgVgBgOgFQgQgHgKgJIgBAAIAABcgAgghrQgRAHgKAMIAABsQAKALARAHQAQAHASAAQAVAAANgLQANgKAFgTQAFgQAAgXQAAgWgFgTQgFgSgNgKQgNgLgVAAQgSAAgQAHg");
	this.shape_35.setTransform(243.1,26.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgIBcIAAinIg8AAIAAgPICJAAIAAAPIg8AAIAACng");
	this.shape_36.setTransform(224.5,22.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AA2BcIAAiYIgBAAIhpCYIgSAAIAAi2IASAAIAACYIAAAAIBpiYIATAAIAAC2g");
	this.shape_37.setTransform(196.5,22.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AA1B+IAAiXIAAAAIhpCXIgTAAIAAi2IASAAIAACYIABAAIBpiYIASAAIAAC2gAgbhiQgLgIgHgMIAKgHQAGAIAIAFQAHAGAQAAQARAAAHgGQAIgFAGgIIAKAHQgHAMgKAIQgMAIgTAAQgSAAgLgIg");
	this.shape_38.setTransform(165.75,19.35);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("ABFBcIAAi2IASAAIAAC2gAhWBcIAAi2IASAAIAABLIAxAAQAdAAAQAOQAQANABAaQgBAagQANQgQAOgdABgAhEBLIAvAAQANABAKgEQAKgEAHgHQAGgJAAgOQAAgOgGgIQgHgJgKgDQgKgDgNAAIgvAAg");
	this.shape_39.setTransform(143.475,22.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AA2BcIAAhXIhrAAIAABXIgTAAIAAi2IATAAIAABRIBrAAIAAhRIASAAIAAC2g");
	this.shape_40.setTransform(121.1,22.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("ABiBcIhYhWIgBAAIAABWIgRAAIAAhWIgBAAIhYBWIgYAAIAAgCIBehaIhbhZIAAgBIAXAAIBWBXIABAAIAAhXIARAAIAABXIABAAIBWhXIAXAAIAAABIhbBZIBeBaIAAACg");
	this.shape_41.setTransform(97.625,22.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgpBUQgUgNgJgWQgJgWAAgbQABgbAKgXQAKgVASgNQATgMAYAAQAaAAARAKQARALAIARQAJARAAAUIgBANIgCALIiJAAQABAXAHARQAHARAQAKQAPAKAWAAQASAAANgGQANgEALgIIAIAOQgMAJgOAGQgQAGgVAAQgeAAgTgNgAgng9QgRARgEAgIB4AAIABgFIAAgFQgBgQgGgOQgGgNgMgGQgNgIgUAAQgaAAgQASg");
	this.shape_42.setTransform(74.65,22.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("ABCByIgCgtIiAAAIgCAtIgPAAIgDg+IAMAAQAJgIAGgKQAHgLAEgQQAEgPACgZIAFhQIBnAAIAAClIARAAIgDA+gAgXggQgCAagEAPQgEAQgFAKQgGAKgHAHIBlAAIAAiVIhEAAg");
	this.shape_43.setTransform(54.175,25.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Ag+BSQgRgOAAgaQAAgdAXgNQAVgOArAAIAfAAIAAgLQAAgegNgMQgPgMgUAAQgRAAgNAFQgNAFgJAIIgJgOQALgJAPgGQAPgGAUAAQAeAAARARQATARAAAlIAABbQAAAHADADQACADAIAAIAKAAIAAAOIgHACIgJAAQgJAAgGgFQgGgFgCgJIgBAAQgJAIgQAHQgQAGgTAAQgaAAgQgPgAgsAMQgQAKAAAUQAAASALAKQAMAKASAAQASAAAOgGQAPgGALgJIAAg6IgdAAQglAAgRALg");
	this.shape_44.setTransform(35.95,22.7993);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("ABKCBIAAh8IiTAAIAAB8IgTAAIAAkBIATAAIAAB0ICTAAIAAh0IATAAIAAEBg");
	this.shape_45.setTransform(13.05,19.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(-2,-7.9,489.5,50.3), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A0SCaIAAkzMAolAAAIAAEzg");
	mask.setTransform(75.3223,15.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSAlQgHgGgEgJQgDgKAAgMQAAgLADgKQAEgJAHgGQAHgGALAAQAMAAAHAGQAIAGADAJQADAKAAALQAAAMgDAKQgDAJgIAGQgHAFgMABQgLgBgHgFgAgNgcQgFAFgCAHQgCAIAAAIQAAAJACAIQACAHAFAFQAFAEAIAAQAJAAAFgEQAFgFACgHQACgIAAgJQAAgIgCgIQgCgHgFgFQgFgEgJAAQgIAAgFAEg");
	this.shape.setTransform(10.125,6.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLAlQgHgFgEgKQgEgJAAgNQAAgMAEgJQAEgKAHgFQAIgGAKAAIAKACIAKAEIgCAHIgJgDQgEgBgFABQgHAAgFAEQgGAEgCAHQgDAIAAAJQAAAKADAIQACAHAGAEQAFAEAHAAIAJAAIAJgDIACAHIgKAEIgKACQgKgBgIgFg");
	this.shape_1.setTransform(2.675,6.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgDgHQgCgHAAgJQAAgIACgHQADgHAGgEQAGgEAIAAIAJABIAIADIgDAIIgGgCIgIgBQgFAAgDADQgEADgCAFQgCAFAAAFQAAAGACAFQACAFAEADQADADAFAAIAIgBIAGgCIADAHIgIADIgJACQgIgBgGgDg");
	this.shape_2.setTransform(-6.5,7.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgOAaQgGgEgDgHQgCgHAAgIQAAgIACgHQADgHAGgEQAGgEAIAAQAJAAAGAEQAGAEADAHQACAHAAAIQAAAIgCAHQgDAHgGAEQgGAEgJABQgIgBgGgEgAgJgSQgDADgCAFQgBAFAAAFQAAAGABAFQACAFADADQAEADAFAAQAGAAADgDQAEgDACgFQABgFAAgGQAAgFgBgFQgCgFgEgDQgDgDgGAAQgFAAgEADg");
	this.shape_3.setTransform(-12.575,7.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYAqIAAhRIAHAAIACAFIAEgDIAHgDIAGgBQAIAAAFAEQAFAEACAHQADAHAAAJQAAAIgDAGQgCAHgFAEQgFAEgIABIgJgCQgEgCgCgCIgBAAIAAAcgAgHgfIgHAEIAAAhIAHAEIAHABQAFAAAEgDQADgDABgFQACgEAAgGQAAgGgCgFQgBgFgDgDQgEgDgFAAIgHABg");
	this.shape_4.setTransform(-18.975,8.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTAjQgGgJAAgQIAAgPQABgHACgHQABgGAFgFQAFgFAIgDIAIgCIAKgCIAIgBIAAAJIgHABIgJABIgIADQgIADgDAGQgDAHAAAMIAEgFIAGgDQAEgCADAAQAIAAAFAEQAFADADAFQADAGAAAJQAAAIgDAGQgDAGgGAEQgGADgIABQgMgBgHgIgAgLACQgEAFAAAJQAAAFACAEQACAFADACQAEADAEAAQAFAAADgDQAEgCACgFQACgEAAgFQAAgJgEgFQgFgEgHAAQgHAAgEAEg");
	this.shape_5.setTransform(-25.675,6.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUAdIAAg5IAKAAIAAA5gAgdAdIAAg5IAKAAIAAAXIAMAAQAJAAAFAEQAFADAAAKQAAAIgFAEQgFAFgJAAgAgTAVIAMAAQAEAAADgCQACgDAAgEQAAgFgCgDQgDgCgEAAIgMAAg");
	this.shape_6.setTransform(-33,7.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgaApIAAhRIAZAAQALAAAHAFQAGAGABAKQgBAHgCAFQgEAFgDABIAAABQAFABAEAFQAEAFgBAIQAAAKgGAGQgGAGgMAAgAgQAgIARAAQAHAAAEgDQAEgDAAgIQAAgHgEgEQgEgDgHAAIgRAAgAgQgDIAOAAQAEAAAEgCQAEgBABgDQACgDAAgFQAAgIgEgDQgEgDgHAAIgOAAg");
	this.shape_7.setTransform(-40.25,6.125);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(-46,0,62.4,14.9), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgEAFQgCgCAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_46.setTransform(153.725,31.15);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AATAdIAAgdIAAgMIgHAMIgJAOIgFAAIgJgOIgHgMIABAMIAAAdIgKAAIAAg5IAJAAIAPAZIADAHIAEgHIAPgZIAJAAIAAA5g");
	this.shape_47.setTransform(148.45,28.8);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_48.setTransform(142.125,28.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAHAFACAJQADAKAAAMQAAANgDAKQgCAJgHAFQgGAFgKABQgJgBgGgFgAgJgcQgFAEgBAHQgBAIgBAJQABAKABAIQABAHAFAEQAEAEAFAAQAHAAADgEQAEgEACgHQABgIABgKQgBgJgBgIQgCgHgEgEQgDgEgHAAQgFAAgEAEg");
	this.shape_49.setTransform(132.7,27.625);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAGAFADAJQADAKAAAMQAAANgDAKQgDAJgGAFQgGAFgKABQgJgBgGgFgAgKgcQgEAEgBAHQgBAIAAAJQAAAKABAIQABAHAEAEQAFAEAFAAQAGAAAFgEQAEgEABgHQACgIAAgKQAAgJgCgIQgBgHgEgEQgFgEgGAAQgFAAgFAEg");
	this.shape_50.setTransform(126.1,27.625);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgVApIAAgJIASAAIAAg9IAAAAIgPAFIgCAAIAAgJIATgHIAHAAIAABIIAQAAIAAAJg");
	this.shape_51.setTransform(119.6,27.625);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgSApIAAgBIAchQIAJAAIAAABIgbBQg");
	this.shape_52.setTransform(113.925,27.625);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AALAdIAAgSIgGACIgHAAQgJAAgFgEQgEgEAAgHIAAgaIAKAAIAAAZQAAADACADQACACAGAAIAGAAIAFgCIAAgfIAKAAIAAA5g");
	this.shape_53.setTransform(108.6,28.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgDATIABgMIgBAAIgKAHIgFgHIAMgHIAAAAIgMgFIAEgHIALAHIAAgNIAHAAIgBANIABAAIALgHIAEAHIgMAFIAMAGIgEAIIgLgIIgBABIABAMg");
	this.shape_54.setTransform(103.225,25.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgQAAIAAgIIApAAIAAAIIgQAAIAAAxg");
	this.shape_55.setTransform(98.15,28.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAYAAQAMAAAGAFQAGAGAAAKQAAAHgCAFQgEAFgEABIAAABQAGABAEAFQAEAFAAAIQAAAKgHAGQgGAGgMAAgAgPAgIAQAAQAHAAAEgDQAEgDAAgIQAAgHgEgEQgEgDgHAAIgQAAgAgPgDIANAAQAFAAADgCQADgBACgDQACgDAAgFQAAgIgEgDQgEgDgHAAIgNAAg");
	this.shape_56.setTransform(92.35,27.625);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_57.setTransform(86.025,28.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgJA0QAFgMADgNQABgNAAgOQAAgNgBgNQgDgOgFgLIAHgEQAFALAEAOQADAOAAAQQAAARgDAPQgEANgFALg");
	this.shape_58.setTransform(78.15,28.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAZAAQAMAAAHAHQAGAGAAAMQAAAMgHAFQgGAHgMAAIgPAAIAAAggAgPAAIAPAAQAHAAAEgDQAEgFAAgHQAAgHgEgEQgEgFgHAAIgPAAg");
	this.shape_59.setTransform(73.5,27.625);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgEApIAAhIIgWAAIAAgJIA1AAIAAAJIgWAAIAABIg");
	this.shape_60.setTransform(66.7,27.625);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgVApIAAhRIAKAAIAABIIAhAAIAAAJg");
	this.shape_61.setTransform(60.925,27.625);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AATApIgOgzIgFgUIAAAAIgEAUIgPAzIgKAAIgVhQIAAgBIALAAIALAwIAFAVIAAAAIAEgVIAPgwIAJAAIAOAwIAFAVIAAAAIAEgVIANgwIAKAAIAAABIgWBQg");
	this.shape_62.setTransform(52.1,27.625);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgFAgQgFgPAAgRQAAgQAFgOQAEgOAEgLIAIAEQgGALgCAOQgDANAAANQAAAOADANQACANAGAMIgIAEQgEgLgEgNg");
	this.shape_63.setTransform(45,28.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgOApQgFgCgFgDIAEgIQAFADAEABIAKABQAEAAAEgBQADgCACgEQACgDAAgFIgBgHQgBgDgEgCQgDgCgGAAIgMAAIAAgIIANAAIAHgCQADgCABgDQACgDAAgEIgCgHQgBgDgDgCQgDgCgEAAIgJABIgKADIgDgIIALgEQAFgCAGAAQALAAAGAHQAGAGAAAKQAAAFgBADIgEAHIgFADIAAABQAFABAEAFQADAFAAAIQAAAHgDAFQgEAGgGADQgGACgHABIgNgCg");
	this.shape_64.setTransform(36.875,27.625);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgHAQIAAgCIAFgdIAKAAIAAACIgIAdg");
	this.shape_65.setTransform(32.1,32.075);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAHAFACAJQADAKAAAMQAAANgDAKQgCAJgHAFQgGAFgKABQgJgBgGgFgAgJgcQgEAEgCAHQgBAIgBAJQABAKABAIQACAHAEAEQADAEAGAAQAGAAAEgEQAFgEABgHQABgIABgKQgBgJgBgIQgBgHgFgEQgEgEgGAAQgGAAgDAEg");
	this.shape_66.setTransform(27.5,27.625);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_67.setTransform(20.825,27.525);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgWAEIAAgIIAtAAIAAAIg");
	this.shape_68.setTransform(14.375,28.45);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgKApIgIgCIgGgCIADgJIAJADIAJABQAHAAAFgEQAEgEABgJQAAgIgFgEQgDgDgIAAIgIAAIgIAAIgBgBIAEgoIAlAAIAAAJIgdAAIgCAXIAEAAIAEAAQAGAAAGADQAHACADAFQADAFABAJQgBAJgEAGQgDAGgHADQgGADgHAAIgHgBg");
	this.shape_69.setTransform(7.8,27.725);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgHAQIAAgCIAFgdIAKAAIAAACIgIAdg");
	this.shape_70.setTransform(2.95,32.075);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_71.setTransform(-1.725,27.525);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_72.setTransform(-8.325,27.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgEAcQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCgAgEgRQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_73.setTransform(182.375,7.325);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgQAaQgFgFAAgIQAAgHADgEQAEgDAFgCQAFgBAFAAIALAAIAAgEQABgGgDgEQgDgDgHAAIgHABIgHADIgEgGQADgDAFgCQAFgCAFAAQAMAAAFAGQAFAGAAAKIAAAlIgHAAIgBgGIAAAAQgEADgFACQgEACgFABQgIgBgEgEgAgHAFQgEACAAAGQAAAEACADQADACAEAAIAHgBQAEgBADgDIAAgPIgKAAQgGAAgDADg");
	this.shape_74.setTransform(177.575,7.325);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgVAdIAAg5IAUAAQAKAAAEAEQAGAEAAAHQAAAFgDAEQgCACgCACQAEAAADAEQACAEAAAFQABAIgGAEQgEAEgKAAgAgLAVIAMAAQAFAAADgCQACgDAAgEQAAgFgCgCQgDgCgFABIgMAAgAgLgEIAKAAQAFABACgCQADgCAAgEQgBgFgCgCQgCgCgFAAIgKAAg");
	this.shape_75.setTransform(172,7.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgRAAIAAgIIArAAIAAAIIgRAAIAAAxg");
	this.shape_76.setTransform(166.4,7.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgCgHQgDgHAAgJQAAgIADgHQACgHAGgEQAGgEAIAAIAJABIAHADIgCAIIgHgCIgHgBQgFAAgDADQgEADgCAFQgBAFAAAFQAAAGABAFQACAFAEADQADADAFAAIAHgBIAHgCIACAHIgHADIgJACQgIgBgGgDg");
	this.shape_77.setTransform(161.15,7.325);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgMAaQgGgEgDgHQgCgHAAgIQAAgHADgHQACgHAGgEQAFgFAIAAQAIAAAFAEQAGADACAGQADAGgBAGIAAAFIAAACIgmAAQAAAGACAEQADAFAEACQADADAFAAQAFAAAEgBIAHgEIADAHIgIAFIgMACQgIgBgGgEgAgGgTQgDACgCAEIgCAJIAcAAIAAgBIAAgCQAAgEgCgDQgBgEgEgBQgDgCgEAAQgEAAgDACg");
	this.shape_78.setTransform(155.2792,7.325);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AALAdIAAgSIgGACIgHAAQgJAAgFgEQgEgEAAgHIAAgaIAKAAIAAAYQAAAEACADQACACAGAAIAGgBIAFgBIAAgfIAKAAIAAA5g");
	this.shape_79.setTransform(149.1,7.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AANAdIAAggIABgMIgBAAIgGAMIgSAgIgLAAIAAg5IAKAAIAAAiIgBAKIAFgKIAUgiIALAAIAAA5g");
	this.shape_80.setTransform(143.05,7.3);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgYAqIAAhRIAHAAIACAFIAEgDIAHgDIAGgBQAIAAAFAEQAFAEACAHQADAHAAAJQAAAIgDAGQgCAHgFAEQgFAEgIABIgJgCQgEgCgCgCIgBAAIAAAcgAgHgfIgHAEIAAAhIAHAEIAHABQAFAAAEgDQADgDABgFQACgEAAgGQAAgGgCgFQgBgFgDgDQgEgDgFAAIgHABg");
	this.shape_81.setTransform(136.675,8.425);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgQAAIAAgIIAqAAIAAAIIgRAAIAAAxg");
	this.shape_82.setTransform(130.75,7.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_83.setTransform(125.725,7.3);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgMAaQgGgEgDgHQgCgHAAgIQAAgHADgHQACgHAGgEQAFgFAIAAQAIAAAFAEQAGADACAGQADAGgBAGIAAAFIAAACIgmAAQAAAGACAEQADAFAEACQADADAFAAQAFAAAEgBIAHgEIADAHIgIAFIgMACQgIgBgGgEgAgGgTQgDACgCAEIgCAJIAcAAIAAgBIAAgCQAAgEgCgDQgBgEgEgBQgDgCgEAAQgEAAgDACg");
	this.shape_84.setTransform(119.4792,7.325);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgZAVQAEAAACgCQACgBABgFIACgOIABgbIAnAAIAAA4IgKAAIAAgwIgUAAIgBATIgCAQQgBAGgDADQgCAEgDAAIgJABg");
	this.shape_85.setTransform(112.875,7.35);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgNAdIgIgDIAEgHIAGACIAHABQAHAAADgFQAFgFABgIIgYAAIAAgHIAYAAQgBgJgFgEQgEgFgGAAIgHABIgGACIgEgIIAIgCIAJgBQAHAAAHADQAFAEAEAHQACAHAAAIQAAAJgCAHQgEAGgFAEQgHAEgHAAIgJgBg");
	this.shape_86.setTransform(107.2,7.325);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AATAkIgBgOIgjAAIgBAOIgHAAIgCgXIAFAAQADgEACgGIACgPIACgXIAjAAIAAAwIAGAAIgCAXgAgGgLIgCAOQgBAHgCADIAXAAIAAgoIgRAAg");
	this.shape_87.setTransform(98.175,8.025);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgOAaQgGgEgDgHQgCgHAAgIQAAgIACgHQADgHAGgEQAGgEAIAAQAJAAAGAEQAGAEADAHQACAHAAAIQAAAIgCAHQgDAHgGAEQgGAEgJABQgIgBgGgEgAgJgSQgDADgCAFQgBAFAAAFQAAAGABAFQACAFADADQAEADAFAAQAGAAADgDQAEgDACgFQABgFAAgGQAAgFgBgFQgCgFgEgDQgDgDgGAAQgFAAgEADg");
	this.shape_88.setTransform(91.825,7.325);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AAOAdIgNgXIgBAAIgNAXIgKAAIAAgBIASgcIgSgaIAAgCIAKAAIANAXIABAAIANgXIAKAAIAAACIgSAaIASAcIAAABg");
	this.shape_89.setTransform(85.7,7.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgDgHQgCgHAAgJQAAgIACgHQADgHAGgEQAGgEAIAAIAJABIAHADIgCAIIgHgCIgHgBQgFAAgDADQgEADgCAFQgBAFAAAFQAAAGABAFQACAFAEADQADADAFAAIAHgBIAHgCIACAHIgHADIgJACQgIgBgGgDg");
	this.shape_90.setTransform(80.15,7.325);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgQAaQgFgFAAgIQAAgHADgEQAEgDAFgCQAFgBAFAAIALAAIAAgEQABgGgDgEQgDgDgHAAIgHABIgHADIgEgGQADgDAFgCQAFgCAFAAQAMAAAFAGQAFAGAAAKIAAAlIgHAAIgBgGIAAAAQgEADgFACQgEACgFABQgIgBgEgEgAgHAFQgEACAAAGQAAAEACADQADACAEAAIAHgBQAEgBADgDIAAgPIgKAAQgGAAgDADg");
	this.shape_91.setTransform(74.175,7.325);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAZAAQAMAAAHAHQAGAGABAMQgBAMgHAFQgGAHgMAAIgPAAIAAAggAgPAAIAPAAQAHAAAEgDQAEgFAAgHQAAgHgEgEQgEgFgHAAIgPAAg");
	this.shape_92.setTransform(68.35,6.125);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgEAFQgCgCAAgDQAAgDACgCQACgBACAAQADAAACABQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_93.setTransform(60.175,9.65);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AATAdIAAgdIAAgMIgGAMIgJAOIgHAAIgJgOIgGgMIAAAMIAAAdIgKAAIAAg5IAKAAIAPAZIADAHIAEgHIAPgZIAKAAIAAA5g");
	this.shape_94.setTransform(54.9,7.3);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_95.setTransform(48.575,7.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgSApIAAgBIAchQIAJAAIAAABIgbBQg");
	this.shape_96.setTransform(43.125,6.125);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgSAdIAAg5IAlAAIAAAIIgbAAIAAAxg");
	this.shape_97.setTransform(38.675,7.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAGAFADAJQADAKAAAMQAAANgDAKQgDAJgGAFQgGAFgKABQgJgBgGgFgAgKgcQgEAEgBAHQgCAIAAAJQAAAKACAIQABAHAEAEQAFAEAFAAQAGAAAFgEQAEgEABgHQABgIAAgKQAAgJgBgIQgBgHgEgEQgFgEgGAAQgFAAgFAEg");
	this.shape_98.setTransform(29.6,6.125);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgEAcQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCgAgEgRQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_99.setTransform(21.725,7.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(-13.5,-3.8,199.7,40.199999999999996), null);


(lib.Symbol19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_6();
	this.instance.setTransform(728.2,-89.65,1.2867,1.2867,0,0,0,103.9,14.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAfIAAgHIATgWIAGgFQACgDAAgFQAAgDgCgEIgDgDQgDgCgCAAQgEAAgEACIgFADIgEgFIAEgDIAFgDIAIgBQAFAAADACQAEACADAFQACAEAAAGIAAAHIgDAEIgFAGIgQASIAAAAIAZAAIAAAHg");
	this.shape.setTransform(615.65,-93.25);

	this.instance_1 = new lib.ClipGroup_1_1();
	this.instance_1.setTransform(725.35,-91.05,1.2867,1.2867,0,0,0,101.7,13.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(524.3,-113.2,334.30000000000007,51.7);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// labais
	this.instance = new lib.Symbol14("synched",0);
	this.instance.setTransform(-17.8,156.25,1,1,10.4494,0,0,194.2,136.2);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({rotation:0,y:156.2},0).wait(1).to({rotation:10.4494,y:156.25},0).wait(1).to({rotation:0,y:156.2},0).wait(1));

	// kreisais
	this.instance_1 = new lib.Symbol13("synched",0);
	this.instance_1.setTransform(-65.2,166.55,1,1,-14.9992,0,0,146.8,146.6);
	this.instance_1.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:146.5,rotation:0,y:166.5},0).wait(1).to({regY:146.6,rotation:-14.9992,y:166.55},0).wait(1).to({regY:146.5,rotation:0,y:166.5},0).wait(1));

	// bee
	this.instance_2 = new lib.Symbol12("synched",0);
	this.instance_2.setTransform(-36.55,166.55,1,1,0,0,0,175,146.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-244.9,-27.6,413.9,373.6);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol11("synched",0);
	this.instance.setTransform(175,146.5,1,1,0,0,0,175,146.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(118).to({startPosition:2},0).to({_off:true},1).wait(121));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-244.9,-27.6,413.9,373.6);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tx
	this.instance = new lib.ClipGroup_3();
	this.instance.setTransform(45.45,124.45,1,1,0,0,0,96.5,10.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({alpha:1},14,cjs.Ease.quadOut).wait(43));

	// vw
	this.instance_1 = new lib.ClipGroup_4();
	this.instance_1.setTransform(46.7,46.7,1,1,0,0,0,46.7,46.7);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,333.7,93.4);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol8();
	this.instance.setTransform(80.05,22,0.055,0.055,0,0,0,80,21.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Symbol8(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:22,scaleX:1,scaleY:1,x:80},14,cjs.Ease.quadOut).wait(45).to({_off:true},1).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,44.1);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t3
	this.instance = new lib.Symbol5("synched",0);
	this.instance.setTransform(123.2,49.3,1,1,0,0,0,127.2,25.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({_off:false},0).to({y:65.55,alpha:1},14,cjs.Ease.quadOut).wait(106).to({startPosition:0},0).to({_off:true},1).wait(89));

	// t2
	this.instance_1 = new lib.Symbol4("synched",0);
	this.instance_1.setTransform(111.4,48.85,1,1,0,0,0,114.2,25.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({_off:false},0).to({y:65.1,alpha:1},14,cjs.Ease.quadOut).wait(57).to({startPosition:0},0).to({alpha:0},15,cjs.Ease.quadOut).to({_off:true},121).wait(89));

	// t1
	this.instance_2 = new lib.ClipGroup_5();
	this.instance_2.setTransform(169.7,0.95,1,1,0,0,0,169.7,17.2);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:17.2,alpha:1},14,cjs.Ease.quadOut).to({_off:true},196).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-24.2,491.5,114.9);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(31.75,93.65,1,1,0,0,0,47.6,47.6);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(31.75,138.8,1,1,0,0,0,47.6,138.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.8,46.1,95.1,95.1);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol19("synched",0);
	this.instance.setTransform(46.95,155.4,1,1,0,0,0,102.9,14.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	// Layer_3
	this.instance_1 = new lib.Symbol18("synched",0);
	this.instance_1.setTransform(45.9,23,1,1,0,0,0,45.9,23);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	// Layer_1
	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.setTransform(46.65,95.35,1,1,0,0,0,59,16.8);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(179.4,27.6,598.7,51.699999999999996);


// stage content:
(lib._300x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bite
	this.instance = new lib.Symbol10("synched",0);
	this.instance.setTransform(150.4,62.3,0.1676,0.1676,41.2674,0,0,-31.9,171.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:-31.8,regY:169.9,scaleX:0.0709,scaleY:0.0709,rotation:26.2616,x:225.9,y:-1.55,startPosition:99},119).to({_off:true},1).wait(189));

	// cta_copy
	this.instance_1 = new lib.Symbol7("synched",0);
	this.instance_1.setTransform(229.35,24.8,0.5449,0.5459,0,0,0,79.8,21.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(249).to({_off:false},0).wait(60));

	// info
	this.instance_2 = new lib.ClipGroup_7("synched",0);
	this.instance_2.setTransform(172.1,24.7,0.4586,0.4586,0,0,0,511.9,52.6);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(189).to({_off:false},0).to({_off:true},60).wait(60));

	// FInal_VW
	this.instance_3 = new lib.Symbol9("synched",0);
	this.instance_3.setTransform(87.9,24.95,0.3506,0.3506,0,0,0,163.5,46.6);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(249).to({_off:false},0).wait(60));

	// BLUE
	this.instance_4 = new lib.Symbol15("synched",0);
	this.instance_4.setTransform(-95.2,25,0.3342,0.3342,0,0,0,212,124.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(179).to({startPosition:0},0).to({scaleX:1.1199,x:71.35},15,cjs.Ease.quadOut).wait(115));

	// TX
	this.instance_5 = new lib.Symbol3("synched",0);
	this.instance_5.setTransform(62.15,17.45,0.3029,0.3029,0,0,0,170.2,17.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},210).wait(99));

	// logo
	this.instance_6 = new lib.Symbol2("synched",0);
	this.instance_6.setTransform(275.2,23.25,0.4967,0.4967,0,0,0,31.9,90.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},210).wait(99));

	// blue
	this.instance_7 = new lib.Symbol1("synched",0);
	this.instance_7.setTransform(70.9,25,0.4286,0.3342,0,0,0,212.1,124.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true},210).wait(99));

	// bg
	this.instance_8 = new lib.Symbol6("synched",0);
	this.instance_8.setTransform(190.6,12.4,0.277,0.277,0,0,0,450.3,387.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regX:450.6,scaleX:0.2288,scaleY:0.2288,x:209.7,y:12.85},194).to({_off:true},16).wait(99));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-16.1,-69.8,325.1,169.6);
// library properties:
lib.properties = {
	id: '2FC8FCDE29FF8F4BBF292F2D27F83343',
	width: 300,
	height: 50,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg.jpg", id:"bg"},
		{src:"images/bite.png", id:"bite"},
		{src:"images/kreisais.png", id:"kreisais"},
		{src:"images/labais.png", id:"labais"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2FC8FCDE29FF8F4BBF292F2D27F83343'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;