(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg = function() {
	this.initialize(img.bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,900,775);


(lib.bite = function() {
	this.initialize(img.bite);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.kreisais = function() {
	this.initialize(img.kreisais);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.labais = function() {
	this.initialize(img.labais);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// flash0_ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAQAbIAAgeIgLAQIgKAAIgKgQIAAAAIAAAeIgPAAIAAg0IAOAAIAQAaIAAAAIAQgaIAPAAIAAA0g");
	this.shape.setTransform(76.7576,38.6051,0.504,0.504);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAJAbIgTgYIAAAYIgOAAIAAg0IAOAAIAAAZIASgZIAQAAIAAABIgUAZIAVAYIAAACg");
	this.shape_1.setTransform(73.5321,38.6051,0.504,0.504);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAANADAGQADAHAGAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_2.setTransform(69.0089,38.0633,0.504,0.504);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAAaAMAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_3.setTransform(65.7582,38.0633,0.504,0.504);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgJgTQgDAGAAANQAAAaAMAAQANAAAAgaQAAgZgNAAQgGAAgDAGg");
	this.shape_4.setTransform(62.5075,38.0633,0.504,0.504);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgMAAQAAAaAMAAQANAAAAgaQAAgZgNAAQgMAAAAAZg");
	this.shape_5.setTransform(57.9717,38.0633,0.504,0.504);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAAQAAgmAcAAQAdAAAAAmQAAAngdAAQgcAAAAgngAgMAAQAAAaAMAAQANAAAAgaQAAgZgNAAQgMAAAAAZg");
	this.shape_6.setTransform(54.721,38.0633,0.504,0.504);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAlIAAgNIARAAIAAgtIgBAAIgNAEIgBAAIAAgNIATgGIAKAAIAAA8IAOAAIAAANg");
	this.shape_7.setTransform(51.5207,38.0633,0.504,0.504);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AALAbIAAggIgTAgIgQAAIAAg0IAOAAIAAAfIATgfIAQAAIAAA0g");
	this.shape_8.setTransform(46.9597,38.6051,0.504,0.504);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgbAPQAFAAADgDQACgEABgJIABgZIArAAIAAA0IgPAAIAAgoIgOAAIgCAOQgBAPgGAGQgFAGgMAAg");
	this.shape_9.setTransform(43.5704,38.6177,0.504,0.504);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAbIAAggIgTAgIgQAAIAAg0IAOAAIAAAfIATgfIAQAAIAAA0g");
	this.shape_10.setTransform(40.4331,38.6051,0.504,0.504);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgkCIIAAjVIhRAAIAAg5IDrAAIAAA5IhSAAIAADVg");
	this.shape_11.setTransform(75.9639,27.1395,0.504,0.504);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhgBmQgignAAg/QAAg8AjgoQAlgrA+AAQA/AAAiAjQAeAfAAAzQAAAYgEAYIi0AAQACAdASAQQASAQAdAAQApAAAugRIARA3QgwAXg+AAQhCAAgmgqgAglhFQgPASgBAaIByAAIABgIQAAg3g5AAQgaAAgQATg");
	this.shape_12.setTransform(61.8523,27.1395,0.504,0.504);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiPBMQAZAAANgPQAPgUADgyIAHh/IDgAAIAAEOIhKAAIAAjVIhTAAIgFBMQgHBSgfAfQgaAbg9AAg");
	this.shape_13.setTransform(45.1075,27.2403,0.504,0.504);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAaIAAgRIgGAAIgOARIgPAAIAAgBIAPgRQgMgDAAgNQAAgSAVAAIAZAAIAAA0gAgGgIQAAAGAGABIALAAIAAgOIgLAAQgGAAAAAHg");
	this.shape_14.setTransform(69.6893,16.3542,0.504,0.504);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AALAaIAAggIAAAAIgTAgIgQAAIAAg0IAOAAIAAAhIABAAIASghIARAAIAAA0g");
	this.shape_15.setTransform(66.6528,16.3542,0.504,0.504);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgGAaIAAgpIgQAAIAAgLIAtAAIAAALIgQAAIAAApg");
	this.shape_16.setTransform(63.7549,16.3542,0.504,0.504);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AALAaIAAgUIgUAAIAAAUIgPAAIAAg0IAPAAIAAAVIAUAAIAAgVIAOAAIAAA0g");
	this.shape_17.setTransform(60.857,16.3542,0.504,0.504);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgaALQAAgQAaAAIAHAAIAAgDQAAgHgIAAQgKAAgIAEIgDgMQAKgEALAAQAWAAAAAVIAAAVQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEAAIAAAKIgIAAQgIABgDgHQgHAHgJAAQgSAAAAgRgAgMAKQAAAGAIABQAGAAAFgFIAAgJIgGAAQgNAAAAAHg");
	this.shape_18.setTransform(57.7701,16.3542,0.504,0.504);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgZAmIAAhKIAKAAIACAFQAKgGAGAAQALAAAHAIQAFAIABAMQgBALgFAIQgHAIgLAAQgGAAgHgFIAAAZgAgKgWIAAAYQAEAEAGAAQALAAAAgPQAAgQgLAAQgFAAgFADg");
	this.shape_19.setTransform(54.6832,16.8582,0.504,0.504);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaALQAAgQAaAAIAHAAIAAgDQAAgHgIAAQgJAAgJAEIgEgMQALgEALAAQAWAAAAAVIAAAVQAAAAAAABQAAAAABAAQAAABAAAAQAAAAABAAIAEAAIAAAKIgIAAQgIABgDgHQgHAHgJAAQgSAAAAgRgAgMAKQAAAGAHABQAGAAAGgFIAAgJIgGAAQgNAAAAAHg");
	this.shape_20.setTransform(51.5207,16.3542,0.504,0.504);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgYAlIAAhJIAxAAIAAAMIgiAAIAAA9g");
	this.shape_21.setTransform(49.1646,15.7999,0.504,0.504);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AmaHLQAYgUAUgZIUIAAIAAqHIzVAAIAAgtIUDAAIAALhgAs3G+QhQgNhAgXIAribQA3AYBEAMQA6ALAxgBQBYABAugmQAtglAAhEQAAhCgrgfQgtgjhhAAQhEAAhxAIIgWgXIAynWIHtAAIAACaIlSAAIgSCyQAlgDAVAAQCcAABUBCQBeBHAACXQAACOhkBPQhjBOiwABQgzAAhJgNg");
	this.shape_22.setTransform(45.4744,23.1083,0.504,0.504);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.3,0,97.6,46.2);


(lib.Symbol17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,900,775);


(lib.Symbol16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLAMQgEgEgBgIQABgGAEgFQAFgEAGgBQAHABAFAEQAFAFAAAGQAAAIgFAEQgFAFgHAAQgGAAgFgFg");
	this.shape.setTransform(255.975,32.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AA1B+IAAiYIAAAAIhpCYIgTAAIAAi2IASAAIAACYIABAAIBpiYIASAAIAAC2gAgbhiQgLgIgHgMIAKgHQAFAHAJAGQAIAGAPAAQAQAAAIgGQAJgGAEgHIALAHQgHAMgKAIQgMAHgTABQgSgBgLgHg");
	this.shape_1.setTransform(241.25,20.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABFBcIAAi2IASAAIAAC2gAhWBcIAAi2IASAAIAABLIAxAAQAdAAAQAOQAQAMABAbQgBAagQANQgQAOgdABgAhEBLIAvAAQANAAAKgDQAKgDAHgJQAGgIAAgOQAAgOgGgJQgHgHgKgEQgKgEgNABIgvAAg");
	this.shape_2.setTransform(218.975,24.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhBBcIAAi2IA8AAQAfgBAPAMQAPAMAAAaQAAAMgHALQgIALgLAFIAAAAQAQADAKALQAJALABARQgBAQgFALQgGAMgOAGQgOAHgXAAgAgvBLIAyAAQAUABALgJQANgIAAgSQAAgTgNgIQgLgIgUABIgyAAgAgvgJIApAAQATABALgIQANgHAAgSQAAgTgMgHQgMgHgTAAIgpAAg");
	this.shape_3.setTransform(198.35,24.049);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA1BcIAAiYIAAAAIhpCYIgTAAIAAi2IASAAIAACYIABAAIBpiYIASAAIAAC2g");
	this.shape_4.setTransform(178.25,24.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgsB/QgTgLgMgXQgLgXAAgkQgBgiAFgcQAEgcANgVQANgWAbgOQAPgGARgFIAlgHIAfgGIAAASQgMADgPABQgPACgRAEQgRADgRAJQgTAKgKAOQgLAOgEATQgFATAAAZIAAAAQAKgRASgKQATgKAXgBQAZABATAKQATALALASQAKATAAAbQAAAZgKATQgLAUgUALQgTALgbAAIgBAAQgYAAgTgLgAgjgIQgPAIgIAQQgJAPAAAVQAAAUAJAQQAIAPAPAJQAPAJAUAAQAWAAAPgJQAPgJAIgPQAIgQAAgUQAAgVgIgPQgIgQgPgIQgPgIgWAAQgUAAgPAIg");
	this.shape_5.setTransform(156.9725,19.9761);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRBUQgTgMgIgWQgJgUAAgZIgsAAIAABXIgSAAIAAi2IASAAIAABRIAtAAQABgYAIgTQAJgUASgMQARgMAeAAQAgAAATAOQATAOAIAVQAHAWAAAZQAAAZgHAWQgIAXgTANQgTANggABQgfgBgRgMgAgJhDQgOAMgGARQgFATAAATQAAAUAFASQAGATAOALQANAMAbAAQAbAAAOgMQAOgLAFgTQAGgSAAgUQAAgTgGgTQgFgRgOgMQgOgMgbAAQgbAAgNAMg");
	this.shape_6.setTransform(131.7,24.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhPBdIAAgRQAIAAAGgCQAGgCAEgIQAEgIADgRQACgRABgeIAEhUIB5AAIAAC2IgSAAIAAimIhWAAIgDBCQgBAhgDAUQgEAVgFAKQgHALgJAEQgIAEgMAAIgDAAg");
	this.shape_7.setTransform(105.75,24.1778);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgyBTQgTgNgHgXQgIgWAAgZQAAgZAIgWQAHgVATgOQATgOAfAAQAgAAATAOQATAOAHAVQAIAWAAAZQAAAZgIAWQgHAXgTANQgTANggABQgfgBgTgNgAgohDQgOAMgGARQgFATAAATQAAAUAFASQAGATAOALQAPAMAZAAQAaAAAPgMQAOgLAGgTQAFgSAAgUQAAgTgFgTQgGgRgOgMQgPgMgaAAQgZAAgPAMg");
	this.shape_8.setTransform(86.375,24.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABCByIgCgtIiAAAIgCAtIgPAAIgDg+IAMAAQAJgIAGgKQAHgLAEgQQAEgPACgZIAFhQIBnAAIAAClIARAAIgDA+gAgXggQgCAagEAPQgEAQgFAKQgGAKgHAHIBlAAIAAiVIhEAAg");
	this.shape_9.setTransform(65.325,26.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhBCDIgMgCIAAgRIALACIANABQANAAAJgKQAJgKAGgOIALgfIhKizIAAgCIATAAIA+CdIABAAIA7idIASAAIAAACIhODTQgIAZgNAMQgOAMgTABIgNgBg");
	this.shape_10.setTransform(47.1,28.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhNCEIAAkBIAPAAIABAQIABAAQALgIAQgHQAQgHAUAAQAcAAAQANQAQANAIAWQAHAWAAAbQAAAagHAVQgIAXgQAMQgQAOgcAAQgUgBgQgFQgOgHgLgJIgBAAIAABcgAgghrQgRAHgKAMIAABsQAKALARAHQAQAHASAAQAVAAANgLQAMgKAGgTQAFgQAAgXQAAgWgFgTQgGgSgMgKQgNgLgVAAQgSAAgQAHg");
	this.shape_11.setTransform(28.2,27.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgIBcIAAinIg7AAIAAgPICIAAIAAAPIg8AAIAACng");
	this.shape_12.setTransform(9.6,24.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-6.7,272.6,50.300000000000004);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#001E50").s().p("EghIATiMAAAgnDMBCRAAAMAAAAnDg");
	this.shape.setTransform(554.95,125.0007,1,2.6784);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(342.9,-209.8,424.20000000000005,669.6);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.labais();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.kreisais();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bite();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,350,293);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#001E50").s().p("AgaAfQgJgMAAgTQAAgSAJgNQAKgNARAAQARAAAKALQAIAKAAAQIgBAKIg4AAQAAAMAHAJQAIAIAKAAQAMAAALgHIAFALQgMAJgSAAQgSAAgKgOgAgOgYQgFAGgBAMIApAAIAAgFQAAgJgFgFQgFgHgKAAQgJAAgGAIg");
	this.shape.setTransform(119.175,23.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#001E50").s().p("AgaAfQgJgMAAgTQAAgSAJgNQAKgNARAAQARAAAKALQAIAKAAAQIgBAKIg4AAQAAAMAHAJQAIAIAKAAQAMAAALgHIAFALQgMAJgSAAQgSAAgKgOgAgOgYQgFAGgBAMIApAAIABgFQAAgJgGgFQgFgHgKAAQgJAAgGAIg");
	this.shape_1.setTransform(110.175,23.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#001E50").s().p("AATAqIAAglIglAAIAAAlIgOAAIAAhTIAOAAIAAAjIAlAAIAAgjIAOAAIAABTg");
	this.shape_2.setTransform(100.875,23.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#001E50").s().p("AgbAzQgKgMAAgZQAAgdADgNQAIgVAUgIQALgDAdgDIAAANQgaACgKAFQgMAEgEAKQgFAJAAARIAAABQALgOAPAAQARAAAJALQAJAKAAASQABASgLALQgKAMgSAAQgRAAgKgNgAgRADQgGAIAAAMQAAAMAGAIQAIAIAJAAQALAAAGgIQAHgIAAgMQAAgMgHgIQgGgGgLgBQgKABgHAGg");
	this.shape_3.setTransform(91.3,21.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#001E50").s().p("AgdAfQgIgLgBgUQABgTAIgMQALgNASAAQAUAAAKANQAJAMAAATQAAAUgJALQgLAOgTAAQgSAAgLgOgAgXAAQAAAhAXgBQAYABgBghQABgggYAAQgXAAAAAgg");
	this.shape_4.setTransform(81.55,23.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#001E50").s().p("AgjA9IAAh2IAKAAIACAHIAAAAQAOgKAMAAQARAAAJANQAHAMAAAUQAAATgHALQgJAOgRAAQgNAAgLgIIAAAAIAAAogAgVgoIAAAxQAIAHANAAQAVABAAggQAAghgVAAQgMAAgJAIg");
	this.shape_5.setTransform(72.2,24.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#001E50").s().p("AAcA1IgBgVIg1AAIgBAVIgLAAIgCgiIAHAAQAKgLABgaIACgiIA0AAIAABHIAJAAIgDAigAgJgSQgCAdgGAIIAjAAIAAg7IgZAAg");
	this.shape_6.setTransform(62.225,24.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#001E50").s().p("AgdAfQgIgLAAgUQAAgsAlAAQATAAAKANQAJAMAAATQAAAUgJALQgKAOgTAAQgTAAgKgOgAgXAAQAAAhAXgBQAYABAAghQAAgggYAAQgXAAAAAgg");
	this.shape_7.setTransform(52.925,23.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#001E50").s().p("AAbA8IAAhqIg1AAIAABqIgPAAIAAh3IBTAAIAAB3g");
	this.shape_8.setTransform(42.275,21.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ApDDcQhbAAhAhBQhBhAAAhbQAAhaBBhAQBAhBBbAAISHAAQBbAABABBQBBBAAABaQAABbhBBAQhABBhbAAg");
	this.shape_9.setTransform(80,22);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4CC7F4").s().p("ApDDcQhbAAhAhBQhBhAAAhbQAAhaBBhAQBAhBBbAAISHAAQBbAABABBQBBBAAABaQAABbhBBAQhABBhbAAg");
	this.shape_10.setTransform(80,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,44);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag0BTQgWgMgLgXQgLgVAAgbQAAgaALgWQALgWAWgNQAVgNAfAAQAgAAAVANQAWANALAWQALAWAAAaQAAAbgLAVQgLAXgWAMQgVANggABQgfgBgVgNgAgfgpQgMAOAAAbQAAAbAMAOQAMAOATAAQAUAAAMgOQAMgOAAgbQAAgbgMgOQgMgNgUAAQgTAAgMANg");
	this.shape.setTransform(241.175,58.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgqCBQgSgFgNgHIAOgmQAMAGAOAEQAOAEARAAQAWAAAKgKQALgJAAgXIAAgNIgBAAQgIAGgNAGQgMAGgSAAQgaAAgSgNQgSgMgJgWQgJgUAAgbQAAgbAJgVQAJgWASgNQASgNAaAAQAMAAALAEQAKADAIAFIAOAKIABAAIAHgQIAoAAIAACqQAAAugZAXQgYAYgtAAQgWgBgSgFgAgchNQgLAOAAAZQAAAZALANQAKAOAWAAQAKAAAJgDIASgHIAAhVQgIgEgKgDQgJgEgKAAQgWABgKAOg");
	this.shape_1.setTransform(218.575,62.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag4BeIAAi2IApAAIAHAWIABAAQAEgGAFgGQAGgHAJgEQAJgEAMAAIAKAAIAJACIgEArIgKgBIgJgBQgPABgKAFQgJAGgFAGIAAB+g");
	this.shape_2.setTransform(201.65,58.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/BaQgOgIgHgNQgHgNAAgRQgBgeAWgOQAVgOAwAAIAYAAIAAgJQAAgLgGgGQgFgFgHgCQgGgCgGAAQgQAAgPADQgQAEgOAGIgMgnQAPgGATgFQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABABAEAAIAOAAIAAAjIgNACIgOABQgPAAgIgFQgJgGgEgLIgBAAQgKAIgQAIQgPAGgRABQgVAAgNgHgAgfATQgLAFAAALQAAALAGAGQAHAFALAAQALAAAKgDQAMgEAIgFIAAghIgTAAQgYAAgLAHg");
	this.shape_3.setTransform(183.3994,58.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpB2QgcgRgPgeQgOgeAAgpQAAgoAOgeQAPgeAcgRQAbgQAogBQASAAATAEQASAFATAIIgPAqQgPgHgOgEQgOgDgQAAQgXABgPALQgQALgHAUQgIAUAAAaQAAAbAIAUQAHAUAQALQAPALAXABQAQAAAOgDQAOgEAPgHIAPAqQgTAIgSAFQgTAEgSAAQgogBgbgQg");
	this.shape_4.setTransform(161.65,55.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhLBbIAAgaIBXh0IAAgBIhRAAIAAgmICQAAIAAAbIhXBzIAAABIBXAAIAAAmg");
	this.shape_5.setTransform(132.05,58.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhKBbIAAgaIBXh0IAAgBIhSAAIAAgmICRAAIAAAbIhYBzIAAABIBYAAIAAAmg");
	this.shape_6.setTransform(114.1,58.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhEBKQgRgTAAgiIAAhyIAzAAIAABtQAAASAHAJQAIAJAQAAQAMAAAKgFQAKgFAGgFIAAiCIAzAAIAAC2IgpAAIgHgSIgBAAIgNAKQgIAGgLADQgJAEgPAAQghAAgQgUg");
	this.shape_7.setTransform(94.225,59.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhkCBIAAkBIBfAAQAuAAAYAQQAYARABAlQgBAVgJANQgKANgOAGIAAABQAVAGAMAPQALAPABAYQAAAkgXATQgWASgyAAgAgvBVIAwAAQAYAAAKgIQALgIAAgRQAAgSgLgIQgLgIgYAAIgvAAgAgvgXIAoAAQAVAAALgHQAKgGAAgRQAAgSgKgGQgKgHgXAAIgnAAg");
	this.shape_8.setTransform(71.675,55.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgXAXQgIgJAAgOQAAgNAIgJQAJgKAOABQAPgBAJAKQAIAJAAANQAAAOgIAJQgJAKgPgBQgOABgJgKg");
	this.shape_9.setTransform(44.625,65.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhqCBIAAkBIBRAAQAvAAAeAPQAdAPANAcQANAdAAApQAAAqgNAdQgNAcgdAPQgeAPgvAAgAg1BVIAXAAQAgAAASgJQASgJAHgTQAHgTgBgdQABgcgHgTQgHgTgSgJQgSgJggAAIgXAAg");
	this.shape_10.setTransform(26.925,55.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZCBIAAkBIAzAAIAAEBg");
	this.shape_11.setTransform(7.65,55.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,28.1,254.5,50.300000000000004);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXB7QgIgJAAgPQAAgOAIgJQAJgJAOAAQAPAAAJAJQAIAJAAAOQAAAPgIAJQgJAJgPAAQgOAAgJgJgAgQAjIgKhtIAAg5IA2AAIAAA5IgLBtg");
	this.shape.setTransform(207.175,55.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/BZQgOgHgHgNQgHgNAAgQQgBgfAWgNQAVgQAwABIAYAAIAAgJQAAgLgGgGQgFgGgHgCQgGgBgGAAQgQAAgPADQgQAEgOAHIgMgoQAPgHATgEQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABACAEAAIAOAAIAAAiIgNACIgOABQgPAAgIgGQgJgFgEgLIgBAAQgKAJgQAGQgPAIgRAAQgVAAgNgIgAgfASQgLAHAAAKQAAALAGAGQAHAFALAAQALAAAKgEQAMgDAIgGIAAgfIgTAAQgYAAgLAFg");
	this.shape_1.setTransform(191.6994,59.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAfBbIhChQIgBAAIAABQIgyAAIAAi1IAyAAIAABXIABAAIBAhXIA3AAIAAACIhHBZIBKBYIAAACg");
	this.shape_2.setTransform(172.125,59.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhgBdIAAgqQAKABAIgFQAIgEAFgMQAFgNACgYIAEhWICXAAIAAC2IgyAAIAAiPIg3AAIgEAzQgDAmgKAVQgKAVgSAHQgRAIgXAAIgDAAg");
	this.shape_3.setTransform(148.925,59.2265);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AguB9QgVgNgKgWQgKgWAAgbQAAgbAKgUQAKgWAVgNQAUgNAdAAQAeAAASAKQAUALAIARQAJASAAAVIgBATIgBAOIh6AAQACATAMAMQAMAKAUABQAPgBAPgDQAPgDANgFIAMAlQgOAHgTAEQgTAFgXgBQgeAAgVgNgAgRgLQgJAGgFAIQgEAKgBAMIBNAAIAAgEIAAgDQABgPgJgKQgIgKgVgBQgMABgJAGgAAZhZQgIgHAAgNQAAgNAIgHQAIgIAOAAQAOAAAHAIQAJAHAAANQAAANgJAHQgHAIgOAAQgOAAgIgIgAg5hZQgJgHAAgNQAAgNAJgHQAIgIANAAQAOAAAIAIQAIAHAAANQAAANgIAHQgIAIgOAAQgNAAgIgIg");
	this.shape_4.setTransform(128.25,54.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeBbIAAg5QgKAEgLACQgLACgQAAQgTAAgNgIQgOgHgHgMQgHgNAAgNIAAhPIAyAAIAABKQAAAJAGAFQAGADANABQAMAAAHgCQAJAAAFgDIAAhXIAxAAIAAC1g");
	this.shape_5.setTransform(107.65,59.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAlBbIAAiPIhJAAIAACPIgyAAIAAi1ICsAAIAAC1g");
	this.shape_6.setTransform(87.15,59.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAfBbIhChQIgBAAIAABQIgyAAIAAi1IAyAAIAABXIABAAIBAhXIA3AAIAAACIhHBZIBKBYIAAACg");
	this.shape_7.setTransform(58.175,59.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/BZQgOgHgHgNQgHgNAAgQQgBgfAWgNQAVgQAwABIAYAAIAAgJQAAgLgGgGQgFgGgHgCQgGgBgGAAQgQAAgPADQgQAEgOAHIgMgoQAPgHATgEQAUgFAVAAQAnAAAUATQATATAAAkIAABKIABAFQABACAEAAIAOAAIAAAiIgNACIgOABQgPAAgIgGQgJgFgEgLIgBAAQgKAJgQAGQgPAIgRAAQgVAAgNgIgAgfASQgLAHAAAKQAAALAGAGQAHAFALAAQALAAAKgEQAMgDAIgGIAAgfIgTAAQgYAAgLAFg");
	this.shape_8.setTransform(36.8994,59.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAsCBIhfhzIgBAAIAABzIg0AAIAAkBIA0AAIAAB9IABAAIBdh9IA7AAIAAAEIhjB/IBoB6IAAAEg");
	this.shape_9.setTransform(15.55,55.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,28.4,214.8,50.300000000000004);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApNCoIAAlPISbAAIAAFPg");
	mask.setTransform(59.025,16.775);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AE8CCQgugmgMg5IAsAAQALAoAhAZQAiAaArAAQA0AAAkglQAlglAAg0QAAgzglglQgkglg0AAQgrAAgiAaQghAZgLAoIgsAAQAMg5AugmQAvgmA8AAQBFAAAxAxQAxAyAABEQAABGgxAxQgxAxhFAAQg8AAgvgmgADDChIhZh+IAzAAIBWB2IAAAIgAgDChIAAh+IArAAIAAB+gAkJChIAAh+IAsAAIAABWICjAAIAAAogAoaChIAAgjIA8hbIAyAAIg4BVIAAABICjAAIAAAogAGQAaQgJgIgCgNImIAAIAAgJIGIAAQACgNAJgIQAKgIANAAQAOAAAKAKQAKAKAAANQAAAOgKAKQgKAKgOAAQgNAAgKgIgAh/AbIAAgHIAEAAQAEAAABgDIABgDIgLgbIAAAAIAIAAIAHASIAGgSIAJAAIAAAAIgNAfQgDAJgIAAgAlQAYIADgGQACACAHAAQAGAAAAgGIAAgCQgEADgEAAQgMAAAAgPQAAgOAMAAQAEAAAFADIABgCIAGAAIAAAaQAAAOgOAAQgGAAgGgDgAlKAAQAAAIAHAAIAFgBIAAgNQgCgBgDAAQgHAAAAAHgAgtALQgEgEAAgHQAAgOAPAAQAPAAAAAOQAAAHgEAEQgEAEgHAAQgHAAgEgEgAgpAAQAAAJAHAAQAHAAAAgJQAAgHgHAAQgHAAAAAHgAhIAHIAAgOIgFAAIAAgEIAFgCIAAgHIAIAAIAAAHIAIAAIAAAGIgIAAIAAAMQAAABAAABQABAAAAABQABAAAAABQABAAABAAIAEgBIAAAGIgHABQgJAAAAgIgAiOAMQgEADgFAAQgKAAAAgJQAAgIAPAAIADAAIAAgBQAAgEgEAAQgGAAgEACIgCgGQAGgDAGAAQAMAAAAAMIAAAKIABABIACAAIAAAGIgEAAQgEAAgCgDgAiZAGQAAABAAAAQABABAAAAQABABAAAAQABAAABAAQADAAADgCIAAgFIgDAAQgHAAAAAEgAktAAQAAgFADgFQAEgEAHAAQAHAAADAEQAEADAAAFIgBAEIgTAAQAAAHAHAAQAGAAADgCIACAGQgFACgGAAQgPAAAAgPgAklgCIAMAAIAAAAQAAgGgGAAQgGAAAAAGgAliAMQgFADgFAAQgJAAAAgJQAAgIAOAAIAEAAIAAgBQAAgEgFAAQgGAAgEACIgCgGQAGgDAGAAQAMAAAAAMIAAAKIABABIADAAIAAAGIgFAAQgDAAgCgDgAluAGQAAADAEAAQAEAAADgCIAAgFIgDAAQgIAAAAAEgAnIANIACgGQAFACAEAAQAFAAAAgDQAAgBgEgCIgEAAQgIgCAAgGQAAgJAMAAQAFAAAGACIgCAGQgEgCgFAAQgBAAgBAAQAAABgBAAQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQABAAABABIADAAQAIACAAAGQAAAJgMAAQgGAAgFgCgAogALQgEgEAAgHQAAgOAPAAQAPAAAAAOQAAAHgEAEQgEAEgHAAQgHAAgEgEgAocAAQAAAJAHAAQAHAAAAgJQAAgHgHAAQgHAAAAAHgAn2APQgIAAAAgIIAAghIAIAAIAAAiIABABIADAAIAAAGgAi3AOIgHgTIgGATIgJAAIgJgbIAAAAIAIAAIAGATIAGgTIAIAAIAHATIAFgTIAIAAIAAAAIgJAbgAj2AOIAAgQQAAgFgFAAIgGACIAAATIgIAAIAAgbIAHAAIABADQAEgEAFAAQAKAAAAALIAAARgAmMAOIgHgTIgGATIgJAAIgIgbIAAAAIAIAAIAFATIAGgTIAJAAIAGATIAFgTIAIAAIAAAAIgIAbgAnYAOIgKgNIAAANIgIAAIAAgoIAIAAIAAAaIAKgNIAJAAIAAAAIgLANIALAOIAAAAgAo/AOIgOgmIAAgBIAIAAIALAfIAKgfIAJAAIAAABIgOAmgACngiQALgNAAgWQAAg0g/AAIhLAAIAABXIgrAAIAAh+IB4AAQAzAAAbAXQAcAYAAAsQAAAUgFAPgAkJgiIAAh+IDNAAIAAAnIihAAIAABXgAmwgiIA5hWIAAgBIibAAIAAgnIDRAAIAAAjIg8Bbg");
	this.shape.setTransform(59.025,16.775);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,118.1,33.6), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A6zF9IAAr5MA1nAAAIAAL5g");
	mask.setTransform(171.625,38.1);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,0,0,4).p("ASNAAMgkZAAA");
	this.shape.setTransform(116.525,38.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(2,0,0,4).p("ACqAAIlTAA");
	this.shape_1.setTransform(326.275,38.1);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,37.1,343.3,2), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Al8F9IAAr5IL5AAIAAL5g");
	mask_1.setTransform(38.125,38.1);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiyC0QhLhLAAhpQAAhoBLhKQBKhLBoAAQBpAABLBLQBKBKAABoQAABphKBLQhLBKhpAAQhoAAhKhKgAjlAAQAABfBEBEQBDBEBeAAQBfAABEhEQBDhEAAhfQAAgogOgnIiHENQgCAGgGABQgFgBgEgGIg9iKQAAgBgBgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQAAABAAABIg+CKQgDAGgFABQgFgBgEgGIiGkNQgPAnAAAogAAUAHQAFAAACAEIAsBlQAAABABAAQAAABAAAAQAAAAABAAQAAABABAAQAAAAAAgBQABAAAAAAQAAAAABgBQAAAAAAgBIB1jrQgggygygcIhUC7QgCAFgFAAIgnAAQgEAAgCgFIhUi7QgyAcgiAyIB2DrQAAABABAAQAAABAAAAQAAAAABAAQAAABABAAQAAAAAAgBQABAAAAAAQABAAAAgBQAAAAAAgBIAthlQABgEAFAAgAhKjYIBJCiQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABgBQAAAAAAgBQABAAAAgBIBIiiQgjgNgogBQgmABgkANg");
	this.shape_1.setTransform(38.1,38.1);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(12.7,12.7,50.8,50.8), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Aw/EdIAAo5MAh/AAAIAAI5g");
	mask_2.setTransform(97.3743,28.4748);

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgOA3IAAhWIghAAIAAgYIBfAAIAAAYIghAAIAABWg");
	this.shape_2.setTransform(147.825,37.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag3BQIAAicIAXAAIAFAKIAJgGIAMgFQAGgCAHAAQARAAAKAIQALAIAFAOQAGAMAAARQAAAQgGAMQgFAOgLAIQgKAIgRAAQgKgBgIgDIgMgIIgBAAIAAA2gAgNgzIgLAEIAAA0QAFAEAGACIAMACQAMgBAHgJQAGgIAAgPQAAgPgGgJQgHgJgMgBQgGABgGACg");
	this.shape_3.setTransform(135.975,40.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgfAzQgNgIgHgOQgHgNAAgQQAAgQAHgMQAHgOANgIQANgIASAAQATAAANAIQANAIAHAOQAHAMAAAQQAAAQgHANQgHAOgNAIQgNAIgTAAQgSAAgNgIgAgTgYQgHAIAAAQQAAARAHAIQAIAJALAAQAMAAAHgJQAIgIAAgRQAAgQgIgIQgHgJgMAAQgLAAgIAJg");
	this.shape_4.setTransform(122.125,37.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAXA3IAAhWIgsAAIAABWIgfAAIAAhuIBoAAIAABug");
	this.shape_5.setTransform(108.6,37.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgTA0QgNgIgHgNQgHgNAAgSQAAgRAHgNQAHgNANgIQANgHASAAQAKAAAKADIAPADIgHAYIgLgCQgGgCgHgBQgJAAgHAEQgGADgEAHQgEAIAAALQAAAMAEAHQAEAIAGADQAHADAJABIANgCIALgEIAHAYIgPAEQgKADgKAAQgSAAgNgHg");
	this.shape_6.setTransform(96.325,37.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAXA3IAAgrIgsAAIAAArIgfAAIAAhuIAfAAIAAAsIAsAAIAAgsIAdAAIAABug");
	this.shape_7.setTransform(83.95,37.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgmA2QgIgEgFgIQgEgIAAgKQAAgTANgHQANgKAdABIAOAAIAAgGQAAgGgDgEQgEgEgEAAIgHgCQgJAAgKADQgKACgIADIgHgXQAJgEAMgDQAMgDANAAQAXAAAMAMQALAMAAAVIAAAsIABADIADABIAIAAIAAAVIgHACIgJAAQgJAAgFgDQgFgDgDgHIgBAAQgFAFgKAEQgJAFgKAAQgNAAgIgFgAgTALQgGAEAAAGQAAAHAEADQAEADAHAAQAGAAAGgBQAHgCAFgEIAAgTIgMAAQgOgBgHAEg");
	this.shape_8.setTransform(71.0491,37.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag3BQIAAicIAXAAIAFAKIAJgGIAMgFQAGgCAHAAQARAAAKAIQALAIAFAOQAGAMAAARQAAAQgGAMQgFAOgLAIQgKAIgRAAQgKgBgIgDIgMgIIgBAAIAAA2gAgNgzIgLAEIAAA0QAFAEAGACIAMACQAMgBAHgJQAGgIAAgPQAAgPgGgJQgHgJgMgBQgGABgGACg");
	this.shape_9.setTransform(58.125,40.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgOA3IAAhWIghAAIAAgYIBfAAIAAAYIghAAIAABWg");
	this.shape_10.setTransform(45.675,37.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAXBSIAAhGIgBAAIgoBGIgiAAIAAhvIAeAAIAABFIABAAIAohFIAiAAIAABvgAgXg0QgJgFgGgJIAKgPQAGAFAHABQAIACAIAAQAJAAAIgCQAHgBAGgFIAKAPQgGAJgKAFQgKAEgOAAQgOAAgKgEg");
	this.shape_11.setTransform(170.775,11.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAXA4IAAhFIgBAAIgoBFIgiAAIAAhvIAeAAIAABFIABAAIAohFIAiAAIAABvg");
	this.shape_12.setTransform(157.125,13.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AASA4IgngxIAAAAIAAAxIgfAAIAAhvIAfAAIAAA1IAAAAIAmg1IAiAAIAAACIgsA1IAuA2IAAACg");
	this.shape_13.setTransform(144.7,13.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgTAzQgNgGgHgOQgHgNAAgSQAAgRAHgNQAHgOANgGQANgIASAAQAKAAAKACIAPAFIgHAXIgLgCQgGgCgHAAQgJgBgHAEQgGADgEAHQgEAIAAALQAAAMAEAIQAEAGAGAEQAHADAJAAIANgBIALgDIAHAXIgPAFQgKACgKAAQgSAAgNgIg");
	this.shape_14.setTransform(132.375,13.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgcAzQgMgIgHgNQgGgOAAgQQAAgQAGgNQAHgNAMgHQAMgJASAAQASAAALAHQALAGAGALQAGALgBANIAAAKIgBAJIhJAAQABAMAHAGQAHAHALAAQAKAAAJgCIARgFIAHAXQgIADgMADQgLADgOAAQgSgBgNgHgAgKgfQgGADgCAGQgDAGAAAGIAuAAIAAgBIAAgCQAAgJgFgHQgFgGgNgBQgHABgFAEg");
	this.shape_15.setTransform(120.5519,13.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AARA4IAAgjIgMADIgQABQgLABgJgFQgIgFgEgHQgEgIAAgHIAAgxIAeAAIAAAuQAAAFAEADQAEACAHAAIAMgBQAFAAACgCIAAg1IAfAAIAABvg");
	this.shape_16.setTransform(108,13.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ag3BQIAAicIAXAAIAFAKIAJgFIAMgGQAGgCAHAAQARABAKAHQALAIAFANQAGAOAAAQQAAAQgGANQgFANgLAIQgKAHgRABQgKgBgIgDIgMgHIgBAAIAAA1gAgNgzIgLAEIAAA0QAFAEAGACIAMABQAMAAAHgJQAGgIAAgPQAAgPgGgJQgHgJgMAAQgGAAgGACg");
	this.shape_17.setTransform(95.675,15.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgcAzQgMgIgHgNQgGgOAAgQQAAgQAGgNQAHgNAMgHQAMgJASAAQASAAALAHQALAGAGALQAGALgBANIAAAKIgBAJIhJAAQABAMAHAGQAHAHALAAQAKAAAJgCIARgFIAHAXQgIADgMADQgLADgOAAQgSgBgNgHgAgKgfQgGADgCAGQgDAGAAAGIAuAAIAAgBIAAgCQAAgJgFgHQgFgGgNgBQgHABgFAEg");
	this.shape_18.setTransform(82.4019,13.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAiA4IAAg/IAAAAIgWAkIgXAAIgWgkIAAAAIAAA/IgeAAIAAhvIAdAAIAiA6IAAAAIAjg6IAdAAIAABvg");
	this.shape_19.setTransform(68.175,13.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAiA4IAAg/IAAAAIgWAkIgXAAIgWgkIAAAAIAAA/IgeAAIAAhvIAdAAIAiA6IAAAAIAjg6IAdAAIAABvg");
	this.shape_20.setTransform(52.325,13.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgfAzQgNgIgHgNQgHgOAAgQQAAgPAHgOQAHgNANgIQANgHASgBQATABANAHQANAIAHANQAHAOAAAPQAAAQgHAOQgHANgNAIQgNAHgTABQgSgBgNgHgAgTgYQgHAIAAAQQAAAQAHAJQAIAIALAAQAMAAAHgIQAIgJAAgQQAAgQgIgIQgHgJgMABQgLgBgIAJg");
	this.shape_21.setTransform(37.625,13.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAbBPIg5hGIgBAAIAABGIggAAIAAidIAgAAIAABNIABAAIA4hNIAjAAIAAADIg8BMIA/BLIAAADg");
	this.shape_22.setTransform(24.225,11.55);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(14,0,165.8,50.6), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AnSHTIAAulIOlAAIAAOlg");
	mask_3.setTransform(46.7,46.7);

	// Layer_3
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AlJFKQiJiIAAjCQAAjBCJiIQCIiJDBAAQDCAACICJQCJCIAADBQAADCiJCIQiICJjCAAQjBAAiIiJgAmmAAQAACvB8B8QB8B9CuAAQCuAAB9h9QB7h8AAivQAAhMgahHIj3HxQgGAMgKAAQgIAAgGgMIhyj/QgCgFgDgBQgBABgDAFIhyD/QgFAMgKAAQgJAAgGgMIj3nxQgbBIAABLgAAlANQAJgBADAJIBRC4QACAGADAAQADAAACgGIDYmwQg9hchcgzIiaFYQgDAIgJAAIhKAAQgIAAgDgIIialYQhdAzg7BcIDXGwQADAGACAAQADAAACgGIBRi4QADgJAIABgAiKmPICGErQADAFABAAQADAAACgFICGkrQhEgYhHAAQhHAAhDAYg");
	this.shape_23.setTransform(46.7,46.7);

	var maskedShapeInstanceList = [this.shape_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_23).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,93.4,93.4), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AA2BcIAAiYIgBAAIhpCYIgSAAIAAi2IASAAIAACYIAAAAIBpiYIATAAIAAC2g");
	this.shape_24.setTransform(196.5,22.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AA1B+IAAiXIAAAAIhpCXIgTAAIAAi2IASAAIAACYIABAAIBpiYIASAAIAAC2gAgbhiQgLgIgHgMIAKgHQAGAIAIAFQAHAGAQAAQARAAAHgGQAIgFAGgIIAKAHQgHAMgKAIQgMAIgTAAQgSAAgLgIg");
	this.shape_25.setTransform(165.75,19.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABFBcIAAi2IASAAIAAC2gAhWBcIAAi2IASAAIAABLIAxAAQAdAAAQAOQAQANABAaQgBAagQANQgQAOgdABgAhEBLIAvAAQANABAKgEQAKgEAHgHQAGgJAAgOQAAgOgGgIQgHgJgKgDQgKgDgNAAIgvAAg");
	this.shape_26.setTransform(143.475,22.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AA2BcIAAhXIhrAAIAABXIgTAAIAAi2IATAAIAABRIBrAAIAAhRIASAAIAAC2g");
	this.shape_27.setTransform(121.1,22.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("ABiBcIhYhWIgBAAIAABWIgRAAIAAhWIgBAAIhYBWIgYAAIAAgCIBehaIhbhZIAAgBIAXAAIBWBXIABAAIAAhXIARAAIAABXIABAAIBWhXIAXAAIAAABIhbBZIBeBaIAAACg");
	this.shape_28.setTransform(97.625,22.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgpBUQgUgNgJgWQgJgWAAgbQABgbAKgXQAKgVASgNQATgMAYAAQAaAAARAKQARALAIARQAJARAAAUIgBANIgCALIiJAAQABAXAHARQAHARAQAKQAPAKAWAAQASAAANgGQANgEALgIIAIAOQgMAJgOAGQgQAGgVAAQgeAAgTgNgAgng9QgRARgEAgIB4AAIABgFIAAgFQgBgQgGgOQgGgNgMgGQgNgIgUAAQgaAAgQASg");
	this.shape_29.setTransform(74.65,22.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("ABCByIgCgtIiAAAIgCAtIgPAAIgDg+IAMAAQAJgIAGgKQAHgLAEgQQAEgPACgZIAFhQIBnAAIAAClIARAAIgDA+gAgXggQgCAagEAPQgEAQgFAKQgGAKgHAHIBlAAIAAiVIhEAAg");
	this.shape_30.setTransform(54.175,25.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("Ag+BSQgRgOAAgaQAAgdAXgNQAVgOArAAIAfAAIAAgLQAAgegNgMQgPgMgUAAQgRAAgNAFQgNAFgJAIIgJgOQALgJAPgGQAPgGAUAAQAeAAARARQATARAAAlIAABbQAAAHADADQACADAIAAIAKAAIAAAOIgHACIgJAAQgJAAgGgFQgGgFgCgJIgBAAQgJAIgQAHQgQAGgTAAQgaAAgQgPgAgsAMQgQAKAAAUQAAASALAKQAMAKASAAQASAAAOgGQAPgGALgJIAAg6IgdAAQglAAgRALg");
	this.shape_31.setTransform(35.95,22.7993);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("ABKCBIAAh8IiTAAIAAB8IgTAAIAAkBIATAAIAAB0ICTAAIAAh0IATAAIAAEBg");
	this.shape_32.setTransform(13.05,19.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(-2,-7.9,211.1,50.3), null);


(lib.ClipGroupcopy4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgEAFQgCgCAAgDQAAgDACgBQACgCACAAQADAAACACQACABAAADQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape.setTransform(153.725,28.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AATAdIAAgdIAAgMIgHAMIgJAOIgFAAIgJgOIgHgMIABAMIAAAdIgKAAIAAg5IAJAAIAPAZIADAHIAEgHIAPgZIAJAAIAAA5g");
	this.shape_1.setTransform(148.45,26);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAbIAXAcIAAABg");
	this.shape_2.setTransform(142.125,26);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAHAFACAJQADAKAAAMQAAANgDAKQgCAJgHAFQgGAFgKABQgJgBgGgFgAgJgcQgFAEgBAHQgBAIgBAJQABAKABAIQABAHAFAEQAEAEAFAAQAHAAADgEQAEgEACgHQABgIABgKQgBgJgBgIQgCgHgEgEQgDgEgHAAQgFAAgEAEg");
	this.shape_3.setTransform(132.7,24.825);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAGAFADAJQADAKAAAMQAAANgDAKQgDAJgGAFQgGAFgKABQgJgBgGgFgAgKgcQgEAEgBAHQgBAIAAAJQAAAKABAIQABAHAEAEQAFAEAFAAQAGAAAFgEQAEgEABgHQACgIAAgKQAAgJgCgIQgBgHgEgEQgFgEgGAAQgFAAgFAEg");
	this.shape_4.setTransform(126.1,24.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVApIAAgJIASAAIAAg9IAAAAIgPAFIgCAAIAAgJIATgHIAHAAIAABIIAQAAIAAAJg");
	this.shape_5.setTransform(119.6,24.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSApIAAgBIAchQIAJAAIAAABIgbBQg");
	this.shape_6.setTransform(113.925,24.825);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AALAdIAAgSIgGACIgHABQgJgBgFgEQgEgEAAgHIAAgaIAKAAIAAAZQAAADACADQACACAGAAIAGAAIAFgCIAAgfIAKAAIAAA5g");
	this.shape_7.setTransform(108.6,26);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDATIABgMIgBAAIgKAGIgFgGIAMgGIAAgBIgMgFIAEgIIALAIIAAgNIAHAAIgBANIABAAIALgIIAEAIIgMAFIAMAGIgEAHIgLgHIgBABIABAMg");
	this.shape_8.setTransform(103.225,22.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgQAAIAAgIIApAAIAAAIIgQAAIAAAxg");
	this.shape_9.setTransform(98.15,26);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAYAAQAMAAAGAFQAGAGAAAKQAAAHgCAFQgEAFgEABIAAABQAGABAEAFQAEAFAAAIQAAAKgHAGQgGAGgMAAgAgPAgIAQAAQAHAAAEgDQAEgDAAgIQAAgHgEgEQgEgDgHAAIgQAAgAgPgDIANAAQAFAAADgCQADgBACgDQACgDAAgFQAAgIgEgDQgEgDgHAAIgNAAg");
	this.shape_10.setTransform(92.35,24.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAbIAXAcIAAABg");
	this.shape_11.setTransform(86.025,26);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgJA0QAFgMADgNQABgNAAgOQAAgNgBgNQgDgOgFgMIAHgDQAFALAEAOQADANAAARQAAASgDAOQgEANgFALg");
	this.shape_12.setTransform(78.15,25.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAZAAQAMAAAHAHQAGAGAAAMQAAAMgHAFQgGAHgMAAIgPAAIAAAggAgPAAIAPAAQAHAAAEgDQAEgFAAgHQAAgHgEgEQgEgFgHAAIgPAAg");
	this.shape_13.setTransform(73.5,24.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgEApIAAhIIgWAAIAAgJIA1AAIAAAJIgWAAIAABIg");
	this.shape_14.setTransform(66.7,24.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgVApIAAhRIAKAAIAABIIAhAAIAAAJg");
	this.shape_15.setTransform(60.925,24.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AATApIgOgzIgFgUIAAAAIgEAUIgPAzIgKAAIgVhQIAAgBIALAAIALAwIAFAVIAAAAIAEgVIAPgwIAJAAIAOAwIAFAVIAAAAIAEgVIANgwIAKAAIAAABIgWBQg");
	this.shape_16.setTransform(52.1,24.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgFAgQgFgOAAgSQAAgRAFgNQAEgOAEgLIAIADQgGAMgCAOQgDANAAANQAAAOADANQACANAGAMIgIAEQgEgLgEgNg");
	this.shape_17.setTransform(45,25.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgOApQgFgCgFgDIAEgIQAFADAEABIAKABQAEAAAEgBQADgCACgEQACgDAAgFIgBgHQgBgDgEgCQgDgCgGAAIgMAAIAAgIIANAAIAHgCQADgCABgDQACgDAAgEIgCgHQgBgDgDgCQgDgCgEAAIgJABIgKADIgDgIIALgEQAFgCAGAAQALAAAGAHQAGAGAAAKQAAAFgBADIgEAHIgFADIAAABQAFABAEAFQADAFAAAIQAAAHgDAFQgEAGgGADQgGACgHABIgNgCg");
	this.shape_18.setTransform(36.875,24.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHAQIAAgCIAFgdIAKAAIAAACIgIAdg");
	this.shape_19.setTransform(32.1,29.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAHAFACAJQADAKAAAMQAAANgDAKQgCAJgHAFQgGAFgKABQgJgBgGgFgAgJgcQgEAEgCAHQgBAIgBAJQABAKABAIQACAHAEAEQADAEAGAAQAGAAAEgEQAFgEABgHQABgIABgKQgBgJgBgIQgBgHgFgEQgEgEgGAAQgGAAgDAEg");
	this.shape_20.setTransform(27.5,24.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_21.setTransform(20.825,24.725);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgWAFIAAgJIAtAAIAAAJg");
	this.shape_22.setTransform(14.375,25.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgKApIgIgCIgGgCIADgJIAJADIAJABQAHAAAFgEQAEgEABgJQAAgIgFgEQgDgDgIAAIgIAAIgIAAIgBgBIAEgoIAlAAIAAAJIgdAAIgCAXIAEAAIAEAAQAGAAAGADQAHACADAFQADAFABAJQgBAJgEAGQgDAGgHADQgGADgHAAIgHgBg");
	this.shape_23.setTransform(7.8,24.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgHAQIAAgCIAFgdIAKAAIAAACIgIAdg");
	this.shape_24.setTransform(2.95,29.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_25.setTransform(-1.725,24.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgWAqIAAgJIAageIAGgIQADgEAAgGQAAgFgCgDQgBgEgEgCQgDgCgEAAQgGAAgEACQgEACgDADIgFgHIAFgEQADgDAFgBQAEgCAGAAQAGAAAFAEQAGADADAFQADAGABAIQAAAFgCAEQgBAEgDADIgGAHIgVAZIAhAAIAAAJg");
	this.shape_26.setTransform(-8.325,24.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgEAcQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCgAgEgRQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_27.setTransform(182.375,7.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgQAaQgFgFAAgIQAAgHADgEQAEgDAFgCQAFgBAFAAIALAAIAAgEQABgGgDgEQgDgDgHAAIgHABIgHADIgEgGQADgDAFgCQAFgCAFAAQAMAAAFAGQAFAGAAAKIAAAlIgHAAIgBgGIAAAAQgEADgFACQgEACgFABQgIgBgEgEgAgHAFQgEACAAAGQAAAEACADQADACAEAAIAHgBQAEgBADgDIAAgPIgKAAQgGAAgDADg");
	this.shape_28.setTransform(177.575,7.325);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgVAdIAAg5IAUAAQAKAAAEAEQAGAEAAAHQAAAFgDAEQgCACgCACQAEAAADAEQACAEAAAFQABAIgGAEQgEAEgKAAgAgLAVIAMAAQAFAAADgCQACgDAAgEQAAgFgCgCQgDgCgFABIgMAAgAgLgEIAKAAQAFABACgCQADgCAAgEQgBgFgCgCQgCgCgFAAIgKAAg");
	this.shape_29.setTransform(172,7.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgRAAIAAgIIArAAIAAAIIgRAAIAAAxg");
	this.shape_30.setTransform(166.4,7.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgCgHQgDgHAAgJQAAgIADgHQACgHAGgEQAGgEAIAAIAJABIAHADIgCAIIgHgCIgHgBQgFAAgDADQgEADgCAFQgBAFAAAFQAAAGABAFQACAFAEADQADADAFAAIAHgBIAHgCIACAHIgHADIgJACQgIgBgGgDg");
	this.shape_31.setTransform(161.15,7.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgMAaQgGgEgDgHQgCgHAAgIQAAgHADgHQACgHAGgEQAFgFAIAAQAIAAAFAEQAGADACAGQADAGgBAGIAAAFIAAACIgmAAQAAAGACAEQADAFAEACQADADAFAAQAFAAAEgBIAHgEIADAHIgIAFIgMACQgIgBgGgEgAgGgTQgDACgCAEIgCAJIAcAAIAAgBIAAgCQAAgEgCgDQgBgEgEgBQgDgCgEAAQgEAAgDACg");
	this.shape_32.setTransform(155.2792,7.325);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AALAdIAAgSIgGACIgHAAQgJAAgFgEQgEgEAAgHIAAgaIAKAAIAAAYQAAAEACADQACACAGAAIAGgBIAFgBIAAgfIAKAAIAAA5g");
	this.shape_33.setTransform(149.1,7.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AANAdIAAggIABgMIgBAAIgGAMIgSAgIgLAAIAAg5IAKAAIAAAiIgBAKIAFgKIAUgiIALAAIAAA5g");
	this.shape_34.setTransform(143.05,7.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgYAqIAAhRIAHAAIACAFIAEgDIAHgDIAGgBQAIAAAFAEQAFAEACAHQADAHAAAJQAAAIgDAGQgCAHgFAEQgFAEgIABIgJgCQgEgCgCgCIgBAAIAAAcgAgHgfIgHAEIAAAhIAHAEIAHABQAFAAAEgDQADgDABgFQACgEAAgGQAAgGgCgFQgBgFgDgDQgEgDgFAAIgHABg");
	this.shape_35.setTransform(136.675,8.425);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgEAdIAAgxIgQAAIAAgIIAqAAIAAAIIgRAAIAAAxg");
	this.shape_36.setTransform(130.75,7.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_37.setTransform(125.725,7.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgMAaQgGgEgDgHQgCgHAAgIQAAgHADgHQACgHAGgEQAFgFAIAAQAIAAAFAEQAGADACAGQADAGgBAGIAAAFIAAACIgmAAQAAAGACAEQADAFAEACQADADAFAAQAFAAAEgBIAHgEIADAHIgIAFIgMACQgIgBgGgEgAgGgTQgDACgCAEIgCAJIAcAAIAAgBIAAgCQAAgEgCgDQgBgEgEgBQgDgCgEAAQgEAAgDACg");
	this.shape_38.setTransform(119.4792,7.325);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgZAVQAEAAACgCQACgBABgFIACgOIABgbIAnAAIAAA4IgKAAIAAgwIgUAAIgBATIgCAQQgBAGgDADQgCAEgDAAIgJABg");
	this.shape_39.setTransform(112.875,7.35);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgNAdIgIgDIAEgHIAGACIAHABQAHAAADgFQAFgFABgIIgYAAIAAgHIAYAAQgBgJgFgEQgEgFgGAAIgHABIgGACIgEgIIAIgCIAJgBQAHAAAHADQAFAEAEAHQACAHAAAIQAAAJgCAHQgEAGgFAEQgHAEgHAAIgJgBg");
	this.shape_40.setTransform(107.2,7.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AATAkIgBgOIgjAAIgBAOIgHAAIgCgXIAFAAQADgEACgGIACgPIACgXIAjAAIAAAwIAGAAIgCAXgAgGgLIgCAOQgBAHgCADIAXAAIAAgoIgRAAg");
	this.shape_41.setTransform(98.175,8.025);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgOAaQgGgEgDgHQgCgHAAgIQAAgIACgHQADgHAGgEQAGgEAIAAQAJAAAGAEQAGAEADAHQACAHAAAIQAAAIgCAHQgDAHgGAEQgGAEgJABQgIgBgGgEgAgJgSQgDADgCAFQgBAFAAAFQAAAGABAFQACAFADADQAEADAFAAQAGAAADgDQAEgDACgFQABgFAAgGQAAgFgBgFQgCgFgEgDQgDgDgGAAQgFAAgEADg");
	this.shape_42.setTransform(91.825,7.325);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAOAdIgNgXIgBAAIgNAXIgKAAIAAgBIASgcIgSgaIAAgCIAKAAIANAXIABAAIANgXIAKAAIAAACIgSAaIASAcIAAABg");
	this.shape_43.setTransform(85.7,7.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgDgHQgCgHAAgJQAAgIACgHQADgHAGgEQAGgEAIAAIAJABIAHADIgCAIIgHgCIgHgBQgFAAgDADQgEADgCAFQgBAFAAAFQAAAGABAFQACAFAEADQADADAFAAIAHgBIAHgCIACAHIgHADIgJACQgIgBgGgDg");
	this.shape_44.setTransform(80.15,7.325);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgQAaQgFgFAAgIQAAgHADgEQAEgDAFgCQAFgBAFAAIALAAIAAgEQABgGgDgEQgDgDgHAAIgHABIgHADIgEgGQADgDAFgCQAFgCAFAAQAMAAAFAGQAFAGAAAKIAAAlIgHAAIgBgGIAAAAQgEADgFACQgEACgFABQgIgBgEgEgAgHAFQgEACAAAGQAAAEACADQADACAEAAIAHgBQAEgBADgDIAAgPIgKAAQgGAAgDADg");
	this.shape_45.setTransform(74.175,7.325);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgZApIAAhRIAZAAQAMAAAHAHQAGAGABAMQgBAMgHAFQgGAHgMAAIgPAAIAAAggAgPAAIAPAAQAHAAAEgDQAEgFAAgHQAAgHgEgEQgEgFgHAAIgPAAg");
	this.shape_46.setTransform(68.35,6.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgEAFQgCgCAAgDQAAgDACgCQACgBACAAQADAAACABQACACAAADQAAADgCACQgCACgDABQgCgBgCgCg");
	this.shape_47.setTransform(60.175,9.65);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AATAdIAAgdIAAgMIgGAMIgJAOIgHAAIgJgOIgGgMIAAAMIAAAdIgKAAIAAg5IAKAAIAPAZIADAHIAEgHIAPgZIAKAAIAAA5g");
	this.shape_48.setTransform(54.9,7.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAKAdIgVgaIAAAaIgKAAIAAg5IAKAAIAAAcIAVgcIALAAIAAABIgWAcIAXAbIAAABg");
	this.shape_49.setTransform(48.575,7.3);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgSApIAAgBIAchQIAJAAIAAABIgbBQg");
	this.shape_50.setTransform(43.125,6.125);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgSAdIAAg5IAlAAIAAAIIgbAAIAAAxg");
	this.shape_51.setTransform(38.675,7.3);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgPAlQgGgFgDgJQgDgKAAgNQAAgMADgKQADgJAGgFQAGgGAJAAQAKAAAGAGQAGAFADAJQADAKAAAMQAAANgDAKQgDAJgGAFQgGAFgKABQgJgBgGgFgAgKgcQgEAEgBAHQgCAIAAAJQAAAKACAIQABAHAEAEQAFAEAFAAQAGAAAFgEQAEgEABgHQABgIAAgKQAAgJgBgIQgBgHgEgEQgFgEgGAAQgFAAgFAEg");
	this.shape_52.setTransform(29.6,6.125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgEAcQgCgCAAgDQAAgDACgCQACgCACAAQADAAACACQACACAAADQAAADgCACQgCACgDABQgCgBgCgCgAgEgRQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAADgCACQgCACgDAAQgCAAgCgCg");
	this.shape_53.setTransform(21.725,7.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroupcopy4, new cjs.Rectangle(-13.5,-3.8,199.7,37.4), null);


(lib.ClipGroup_1copy2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A0SCaIAAkzMAolAAAIAAEzg");
	mask.setTransform(75.3223,15.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSAlQgHgGgEgJQgDgKAAgMQAAgLADgKQAEgJAHgGQAHgGALAAQAMAAAHAGQAIAGADAJQADAKAAALQAAAMgDAKQgDAJgIAGQgHAFgMABQgLgBgHgFgAgNgcQgFAFgCAHQgCAIAAAIQAAAJACAIQACAHAFAFQAFAEAIAAQAJAAAFgEQAFgFACgHQACgIAAgJQAAgIgCgIQgCgHgFgFQgFgEgJAAQgIAAgFAEg");
	this.shape.setTransform(10.125,6.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLAlQgHgFgEgKQgEgJAAgNQAAgMAEgJQAEgKAHgFQAIgGAKAAIAKACIAKAEIgCAHIgJgDQgEgBgFABQgHAAgFAEQgGAEgCAHQgDAIAAAJQAAAKADAIQACAHAGAEQAFAEAHAAIAJAAIAJgDIACAHIgKAEIgKACQgKgBgIgFg");
	this.shape_1.setTransform(2.675,6.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAbQgGgEgDgHQgCgHAAgJQAAgIACgHQADgHAGgEQAGgEAIAAIAJABIAIADIgDAIIgGgCIgIgBQgFAAgDADQgEADgCAFQgCAFAAAFQAAAGACAFQACAFAEADQADADAFAAIAIgBIAGgCIADAHIgIADIgJACQgIgBgGgDg");
	this.shape_2.setTransform(-6.5,7.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgOAaQgGgEgDgHQgCgHAAgIQAAgIACgHQADgHAGgEQAGgEAIAAQAJAAAGAEQAGAEADAHQACAHAAAIQAAAIgCAHQgDAHgGAEQgGAEgJABQgIgBgGgEgAgJgSQgDADgCAFQgBAFAAAFQAAAGABAFQACAFADADQAEADAFAAQAGAAADgDQAEgDACgFQABgFAAgGQAAgFgBgFQgCgFgEgDQgDgDgGAAQgFAAgEADg");
	this.shape_3.setTransform(-12.575,7.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYAqIAAhRIAHAAIACAFIAEgDIAHgDIAGgBQAIAAAFAEQAFAEACAHQADAHAAAJQAAAIgDAGQgCAHgFAEQgFAEgIABIgJgCQgEgCgCgCIgBAAIAAAcgAgHgfIgHAEIAAAhIAHAEIAHABQAFAAAEgDQADgDABgFQACgEAAgGQAAgGgCgFQgBgFgDgDQgEgDgFAAIgHABg");
	this.shape_4.setTransform(-18.975,8.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTAjQgGgJAAgQIAAgPQABgHACgHQABgGAFgFQAFgFAIgDIAIgCIAKgCIAIgBIAAAJIgHABIgJABIgIADQgIADgDAGQgDAHAAAMIAEgFIAGgDQAEgCADAAQAIAAAFAEQAFADADAFQADAGAAAJQAAAIgDAGQgDAGgGAEQgGADgIABQgMgBgHgIgAgLACQgEAFAAAJQAAAFACAEQACAFADACQAEADAEAAQAFAAADgDQAEgCACgFQACgEAAgFQAAgJgEgFQgFgEgHAAQgHAAgEAEg");
	this.shape_5.setTransform(-25.675,6.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAUAdIAAg5IAKAAIAAA5gAgdAdIAAg5IAKAAIAAAXIAMAAQAJAAAFAEQAFADAAAKQAAAIgFAEQgFAFgJAAgAgTAVIAMAAQAEAAADgCQACgDAAgEQAAgFgCgDQgDgCgEAAIgMAAg");
	this.shape_6.setTransform(-33,7.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgaApIAAhRIAZAAQALAAAHAFQAGAGABAKQgBAHgCAFQgEAFgDABIAAABQAFABAEAFQAEAFgBAIQAAAKgGAGQgGAGgMAAgAgQAgIARAAQAHAAAEgDQAEgDAAgIQAAgHgEgEQgEgDgHAAIgRAAgAgQgDIAOAAQAEAAAEgCQAEgBABgDQACgDAAgFQAAgIgEgDQgEgDgHAAIgOAAg");
	this.shape_7.setTransform(-40.25,6.125);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1copy2, new cjs.Rectangle(-46,0,62.4,14.9), null);


(lib.Symbol19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroupcopy4();
	this.instance.setTransform(140.45,13.4,1.0277,1.0277,0,0,0,104,14.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAZIAAgFIAPgSIAEgFQACgCAAgEIgBgFIgDgDIgEgBIgGABIgEADIgDgEIADgDIAEgCIAGgBQADAAAEACQADACACADQACAEAAAEIgBAGIgCADIgEAFIgMAOIATAAIAAAGg");
	this.shape.setTransform(50.475,10.525);

	this.instance_1 = new lib.ClipGroup_1copy2();
	this.instance_1.setTransform(138.15,12.25,1.0277,1.0277,0,0,0,101.8,13.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.5,-5.3,267,38.4);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// labais
	this.instance = new lib.Symbol14("synched",0);
	this.instance.setTransform(-17.8,156.25,1,1,10.4494,0,0,194.2,136.2);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({rotation:0,y:156.2},0).wait(1).to({rotation:10.4494,y:156.25},0).wait(1).to({rotation:0,y:156.2},0).wait(1));

	// kreisais
	this.instance_1 = new lib.Symbol13("synched",0);
	this.instance_1.setTransform(-65.2,166.55,1,1,-14.9992,0,0,146.8,146.6);
	this.instance_1.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:146.5,rotation:0,y:166.5},0).wait(1).to({regY:146.6,rotation:-14.9992,y:166.55},0).wait(1).to({regY:146.5,rotation:0,y:166.5},0).wait(1));

	// bee
	this.instance_2 = new lib.Symbol12("synched",0);
	this.instance_2.setTransform(-36.55,166.55,1,1,0,0,0,175,146.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-244.9,-27.6,413.9,373.6);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol11("synched",0);
	this.instance.setTransform(175,146.5,1,1,0,0,0,175,146.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(118).to({startPosition:2},0).to({_off:true},1).wait(121));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-244.9,-27.6,413.9,373.6);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// tx
	this.instance = new lib.ClipGroup_3();
	this.instance.setTransform(45.45,124.45,1,1,0,0,0,96.5,10.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).to({alpha:1},14,cjs.Ease.quadOut).wait(43));

	// vw
	this.instance_1 = new lib.ClipGroup_4();
	this.instance_1.setTransform(46.7,46.7,1,1,0,0,0,46.7,46.7);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.5,0,217.7,170.9);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol8();
	this.instance.setTransform(80.05,22,0.055,0.055,0,0,0,80,21.8);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.Symbol8(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:22,scaleX:1,scaleY:1,x:80},14,cjs.Ease.quadOut).wait(91).to({_off:true},1).wait(14));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,44.1);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol17("synched",0);
	this.instance.setTransform(201.15,452.8,0.8051,0.8051,0,0,0,449.9,387.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-161,140.7,724.6,623.9000000000001);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// t3
	this.instance = new lib.Symbol5("synched",0);
	this.instance.setTransform(123.2,49.3,1,1,0,0,0,127.2,25.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({_off:false},0).to({y:65.55,alpha:1},14,cjs.Ease.quadOut).wait(106).to({startPosition:0},0).to({_off:true},1).wait(89));

	// t2
	this.instance_1 = new lib.Symbol4("synched",0);
	this.instance_1.setTransform(111.4,48.85,1,1,0,0,0,114.2,25.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).to({y:65.1,alpha:1},14,cjs.Ease.quadOut).wait(54).to({startPosition:0},0).to({alpha:0},15,cjs.Ease.quadOut).to({_off:true},121).wait(89));

	// Layer_2
	this.instance_2 = new lib.Symbol16("synched",0);
	this.instance_2.setTransform(90.7,40.2,1,1,0,0,0,92.7,25.2);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({_off:false},0).to({y:61.8,alpha:1},14,cjs.Ease.quadOut).wait(192).to({startPosition:0},0).to({_off:true},1).wait(1).to({_off:false},0).wait(88));

	// t1
	this.instance_3 = new lib.ClipGroup_5();
	this.instance_3.setTransform(169.7,0.95,1,1,0,0,0,169.7,17.2);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({y:17.2,alpha:1},14,cjs.Ease.quadOut).to({_off:true},196).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-24.2,274.6,142.9);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_2();
	this.instance.setTransform(-300.7,378.4,1,1,0,0,0,38.1,38.1);

	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.setTransform(-400.25,378.4,1,1,0,0,0,171.6,38.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-572.8,340.3,345.19999999999993,76.19999999999999);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Symbol19("synched",0);
	this.instance.setTransform(46.95,155.4,1,1,0,0,0,102.9,14.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({alpha:1},14,cjs.Ease.quadOut).wait(42));

	// Layer_1
	this.instance_1 = new lib.ClipGroup();
	this.instance_1.setTransform(46.65,95.35,1,1,0,0,0,59,16.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({alpha:1},14,cjs.Ease.quadOut).wait(44));

	// Layer_3
	this.instance_2 = new lib.Symbol18("synched",0);
	this.instance_2.setTransform(45.9,23,1,1,0,0,0,45.9,23);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({alpha:1},14,cjs.Ease.quadOut).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.7,0,238.7,174);


// stage content:
(lib._320x480 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ClipGroup_6("synched",0);
	this.instance.setTransform(160.5,295.7,1.0667,1.0667,0,0,0,46,23);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(189).to({_off:false},0).wait(60));

	// FInal_VW
	this.instance_1 = new lib.Symbol9("synched",0);
	this.instance_1.setTransform(159.85,118.35,0.9536,0.9536,0,0,0,46.7,46.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(189).to({_off:false},0).wait(60));

	// BLUE
	this.instance_2 = new lib.Symbol15("synched",0);
	this.instance_2.setTransform(-597.25,240,1.0667,1.0667,0,0,0,212.1,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(179).to({startPosition:0},0).to({x:-261.6},15,cjs.Ease.quadOut).wait(55));

	// cta
	this.instance_3 = new lib.Symbol7("synched",0);
	this.instance_3.setTransform(108.8,210.45,0.9995,0.9996,0,0,0,80,22.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(89).to({_off:false},0).to({_off:true},106).wait(54));

	// TX
	this.instance_4 = new lib.Symbol3("synched",0);
	this.instance_4.setTransform(201.4,54.75,1.0029,1.0029,0,0,0,169.8,17.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},210).wait(39));

	// bite
	this.instance_5 = new lib.Symbol10("synched",0);
	this.instance_5.setTransform(28.15,544.65,0.7284,0.7284,29.7994,0,0,-31.9,171.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:-31.7,regY:171.1,scaleX:0.2262,scaleY:0.2262,rotation:71.2668,x:364.9,y:-56.15,startPosition:99},119).to({_off:true},1).wait(129));

	// logo
	this.instance_6 = new lib.Symbol2("synched",0);
	this.instance_6.setTransform(608,173,1.0667,1.0667,0,0,0,31.8,138.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},210).wait(39));

	// bg
	this.instance_7 = new lib.Symbol6("synched",0);
	this.instance_7.setTransform(322,199.85,0.8842,0.8842,0,0,0,450.2,387.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:450.4,regY:387.2,scaleX:0.8722,scaleY:0.8722,x:472.2,y:198.25},194).to({_off:true},16).wait(39));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-297.7,122.9,868.5999999999999,577.8000000000001);
// library properties:
lib.properties = {
	id: '2FC8FCDE29FF8F4BBF292F2D27F83343',
	width: 320,
	height: 480,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bg.jpg", id:"bg"},
		{src:"images/bite.png", id:"bite"},
		{src:"images/kreisais.png", id:"kreisais"},
		{src:"images/labais.png", id:"labais"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['2FC8FCDE29FF8F4BBF292F2D27F83343'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;